package com.example.ui.screens

import android.app.Activity
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ExitToApp
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.BridgeGameUiState
import com.example.model.GameMode
import com.example.ui.canvas.EntityDrawers.drawCapybaraCrocodileSquad

@Composable
fun MainMenuScreen(
  uiState: BridgeGameUiState,
  unclaimedAchievementsCount: Int,
  onStartEndless: () -> Unit,
  onStartCampaign: () -> Unit,
  onOpenPermanentUpgrades: () -> Unit,
  onOpenStatsAndAchievements: () -> Unit,
  onOpenCompendium: () -> Unit,
  onOpenSettings: () -> Unit,
  modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val perm = uiState.permanentUpgrades
  val stats = uiState.playerStats

  Box(
    modifier = modifier
      .fillMaxSize()
      .background(
        Brush.verticalGradient(
          colors = listOf(Color(0xFF0F172A), Color(0xFF1E293B), Color(0xFF0F172A))
        )
      )
  ) {
    // Decorative Capybara Hero Artwork in Background
    Canvas(modifier = Modifier.fillMaxSize()) {
      drawCapybaraCrocodileSquad(
        playerX = 0.50f,
        squadCount = 3,
        muzzleFlash = 0.6f,
        canvasW = size.width,
        canvasH = size.height * 0.42f
      )
    }

    Column(
      modifier = Modifier
        .fillMaxSize()
        .statusBarsPadding()
        .navigationBarsPadding()
        .padding(horizontal = 20.dp, vertical = 14.dp)
        .verticalScroll(rememberScrollState()),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.SpaceBetween
    ) {
      // Top Currency & Records Bar
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 520.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Surface(
          color = Color(0xD91E293B),
          shape = RoundedCornerShape(50),
          modifier = Modifier.border(1.5.dp, Color(0xFFFACC15), RoundedCornerShape(50))
        ) {
          Row(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            Text(
              text = "🪙 ${perm.gold}",
              color = Color(0xFFFACC15),
              fontWeight = FontWeight.ExtraBold,
              fontSize = 15.sp
            )
            Text(
              text = "💎 ${perm.crystals}",
              color = Color(0xFF38BDF8),
              fontWeight = FontWeight.ExtraBold,
              fontSize = 15.sp
            )
          }
        }

        Surface(
          color = Color(0xD91E293B),
          shape = RoundedCornerShape(50),
          modifier = Modifier.border(1.5.dp, Color(0xFF4ADE80), RoundedCornerShape(50))
        ) {
          Text(
            text = "Угроза Макс: Ур. ${stats.bestEndlessThreatLevel} • Волна ${perm.unlockedWave}",
            color = Color(0xFF86EFAC),
            fontWeight = FontWeight.Bold,
            fontSize = 12.sp,
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Game Title Banner
      Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(vertical = 8.dp)
      ) {
        Text(
          text = "ОБОРОНА МОСТА",
          style = TextStyle(
            color = Color(0xFFFACC15),
            fontSize = 32.sp,
            fontWeight = FontWeight.Black,
            shadow = Shadow(color = Color.Black, blurRadius = 12f)
          ),
          textAlign = TextAlign.Center
        )
        Text(
          text = "КАПИБАРЫ ПРОТИВ БЕСКОНЕЧНОЙ ОРДЫ",
          color = Color(0xFFBAE6FD),
          fontWeight = FontWeight.ExtraBold,
          fontSize = 13.sp,
          textAlign = TextAlign.Center
        )
      }

      Spacer(modifier = Modifier.height(70.dp))

      // Main Menu Card with Play Modes, Permanent Upgrades, Stats/Achievements, Settings, and Exit
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .widthIn(max = 480.dp)
          .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(26.dp)),
        shape = RoundedCornerShape(26.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xE60F172A))
      ) {
        Column(
          modifier = Modifier.padding(20.dp),
          verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
          // 1. PLAY: ENDLESS MODE (Primary Featured Mode!)
          Button(
            onClick = onStartEndless,
            modifier = Modifier
              .fillMaxWidth()
              .height(64.dp)
              .testTag("menu_play_endless_button"),
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFEA580C))
          ) {
            Icon(
              imageVector = Icons.Default.LocalFireDepartment,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(28.dp)
            )
            Spacer(modifier = Modifier.width(10.dp))
            Column(horizontalAlignment = Alignment.Start) {
              Text(
                text = "ИГРАТЬ: БЕСКОНЕЧНЫЙ РЕЖИМ",
                color = Color.White,
                fontWeight = FontWeight.Black,
                fontSize = 15.sp
              )
              Text(
                text = "Бесконечный рост ХП, новые мутанты и добыча 💎",
                color = Color(0xFFFED7AA),
                fontSize = 11.sp,
                fontWeight = FontWeight.SemiBold
              )
            }
          }

          // 2. PLAY: CAMPAIGN WAVE MODE
          Button(
            onClick = onStartCampaign,
            modifier = Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("menu_play_campaign_button"),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
          ) {
            Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.White)
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "КАМПАНИЯ • ВОЛНА ${perm.unlockedWave}",
              color = Color.White,
              fontWeight = FontWeight.ExtraBold,
              fontSize = 15.sp
            )
          }

          // 3. PERMANENT UPGRADES (Crystal Lab & Gold Armory)
          Button(
            onClick = onOpenPermanentUpgrades,
            modifier = Modifier
              .fillMaxWidth()
              .height(54.dp)
              .testTag("menu_upgrades_button"),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
          ) {
            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color(0xFFFDE047))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "ЭВОЛЮЦИЯ И АРСЕНАЛ (${perm.crystals} 💎 / ${perm.gold} 🪙)",
              color = Color.White,
              fontWeight = FontWeight.ExtraBold,
              fontSize = 14.sp
            )
          }

          // 4. STATS & ACHIEVEMENTS
          Button(
            onClick = onOpenStatsAndAchievements,
            modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("menu_stats_achievements_button"),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF7C3AED))
          ) {
            Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = Color(0xFFFACC15))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = if (unclaimedAchievementsCount > 0) {
                "СТАТИСТИКА И ДОСТИЖЕНИЯ (+$unclaimedAchievementsCount 🎁)"
              } else {
                "СТАТИСТИКА И ДОСТИЖЕНИЯ"
              },
              color = Color.White,
              fontWeight = FontWeight.ExtraBold,
              fontSize = 14.sp
            )
          }

          // 5. ROW: SETTINGS & COMPENDIUM
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            OutlinedButton(
              onClick = onOpenSettings,
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("menu_settings_button"),
              shape = RoundedCornerShape(14.dp)
            ) {
              Icon(Icons.Default.Settings, contentDescription = null, tint = Color.White)
              Spacer(modifier = Modifier.width(6.dp))
              Text("Настройки", color = Color.White, fontWeight = FontWeight.Bold)
            }

            OutlinedButton(
              onClick = onOpenCompendium,
              modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("menu_compendium_button"),
              shape = RoundedCornerShape(14.dp)
            ) {
              Icon(Icons.Default.MenuBook, contentDescription = null, tint = Color(0xFF38BDF8))
              Spacer(modifier = Modifier.width(6.dp))
              Text("Бестиарий", color = Color.White, fontWeight = FontWeight.Bold)
            }
          }

          // 6. EXIT BUTTON
          OutlinedButton(
            onClick = { (context as? Activity)?.finish() },
            modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("menu_exit_button"),
            shape = RoundedCornerShape(14.dp)
          ) {
            Icon(Icons.AutoMirrored.Filled.ExitToApp, contentDescription = null, tint = Color(0xFFF87171))
            Spacer(modifier = Modifier.width(8.dp))
            Text(
              text = "Выход из Игры",
              color = Color(0xFFF87171),
              fontWeight = FontWeight.Bold
            )
          }
        }
      }
    }
  }
}
