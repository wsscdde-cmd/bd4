package com.example.ui.canvas

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import com.example.model.ActiveTurret
import com.example.model.BridgeMine
import com.example.model.FallingBuffDrop
import com.example.model.LeftBarrel
import com.example.model.PlantType
import com.example.model.RightBarrel
import com.example.model.SawbladeWave
import com.example.model.UpgradeType
import com.example.model.Zombie
import com.example.model.ZombieType
import kotlin.math.cos
import kotlin.math.sin

object EntityDrawers {

  private val strokeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    style = Paint.Style.STROKE
    textAlign = Paint.Align.CENTER
    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
    strokeJoin = Paint.Join.ROUND
    strokeCap = Paint.Cap.ROUND
  }

  private val fillTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
    style = Paint.Style.FILL
    textAlign = Paint.Align.CENTER
    typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
  }

  fun DrawScope.drawOutlinedText(
    text: String,
    x: Float,
    y: Float,
    textSizePx: Float,
    fillColor: Int = android.graphics.Color.WHITE,
    strokeColor: Int = android.graphics.Color.BLACK,
    strokeWidthPx: Float = textSizePx * 0.22f
  ) {
    strokeTextPaint.textSize = textSizePx
    strokeTextPaint.color = strokeColor
    strokeTextPaint.strokeWidth = strokeWidthPx

    fillTextPaint.textSize = textSizePx
    fillTextPaint.color = fillColor

    drawContext.canvas.nativeCanvas.apply {
      drawText(text, x, y, strokeTextPaint)
      drawText(text, x, y, fillTextPaint)
    }
  }

  fun DrawScope.drawZombie(zombie: Zombie, canvasW: Float, canvasH: Float) {
    val cx = zombie.x * canvasW
    val cy = zombie.y * canvasH
    val baseUnit = canvasW * 0.066f * zombie.type.scale
    val bobY = sin(zombie.walkPhase) * (baseUnit * 0.08f)

    if (zombie.type == ZombieType.NECRO_SHAMAN) {
      drawCircle(
        color = Color(0x44A855F7),
        radius = baseUnit * 0.72f,
        center = Offset(cx, cy)
      )
    } else if (zombie.type == ZombieType.TOXIC_MUTANT) {
      drawCircle(
        color = Color(0x444ADE80),
        radius = baseUnit * 0.65f,
        center = Offset(cx, cy)
      )
    }

    drawOval(
      color = Color(0x44000000),
      topLeft = Offset(cx - baseUnit * 0.42f, cy + baseUnit * 0.55f),
      size = Size(baseUnit * 0.84f, baseUnit * 0.26f)
    )

    val leftFootBob = sin(zombie.walkPhase) * (baseUnit * 0.06f)
    val rightFootBob = -leftFootBob
    drawRoundRect(
      color = Color(0xFF334155),
      topLeft = Offset(cx - baseUnit * 0.28f, cy + baseUnit * 0.28f + leftFootBob),
      size = Size(baseUnit * 0.23f, baseUnit * 0.34f),
      cornerRadius = CornerRadius(baseUnit * 0.08f)
    )
    drawRoundRect(
      color = Color(0xFF334155),
      topLeft = Offset(cx + baseUnit * 0.05f, cy + baseUnit * 0.28f + rightFootBob),
      size = Size(baseUnit * 0.23f, baseUnit * 0.34f),
      cornerRadius = CornerRadius(baseUnit * 0.08f)
    )

    val shirtColor = when {
      zombie.hitFlash > 0.2f -> Color.White
      zombie.slowTimer > 0f -> Color(0xFF38BDF8)
      zombie.type == ZombieType.BOSS -> Color(0xFF991B1B)
      zombie.type == ZombieType.CYBER_JUGGERNAUT -> Color(0xFF475569)
      zombie.type == ZombieType.NECRO_SHAMAN -> Color(0xFF6B21A8)
      zombie.type == ZombieType.TOXIC_MUTANT -> Color(0xFF16A34A)
      zombie.type == ZombieType.SHIELD_BRUTE -> Color(0xFF1D4ED8)
      zombie.type == ZombieType.SPRINTER -> Color(0xFFDC2626)
      else -> Color(0xFFEA580C)
    }
    val bodyTop = cy - baseUnit * 0.08f + bobY
    val bodyW = baseUnit * 0.72f
    val bodyH = baseUnit * 0.48f
    drawRoundRect(
      color = shirtColor,
      topLeft = Offset(cx - bodyW / 2f, bodyTop),
      size = Size(bodyW, bodyH),
      cornerRadius = CornerRadius(baseUnit * 0.18f)
    )
    drawRoundRect(
      color = Color(0xFF1E293B),
      topLeft = Offset(cx - bodyW / 2f, bodyTop),
      size = Size(bodyW, bodyH),
      cornerRadius = CornerRadius(baseUnit * 0.18f),
      style = Stroke(width = 2.5f)
    )

    val zigY = bodyTop + bodyH * 0.72f
    drawLine(
      color = Color(0xFFFDE047),
      start = Offset(cx - bodyW * 0.38f, zigY),
      end = Offset(cx + bodyW * 0.38f, zigY),
      strokeWidth = 3f
    )

    val headCenterY = cy - baseUnit * 0.32f + bobY
    val headRadius = baseUnit * 0.39f
    val skinColor = when {
      zombie.hitFlash > 0.2f -> Color.White
      zombie.slowTimer > 0f -> Color(0xFF7DD3FC)
      zombie.type == ZombieType.TOXIC_MUTANT -> Color(0xFF4ADE80)
      zombie.type == ZombieType.CYBER_JUGGERNAUT -> Color(0xFF94A3B8)
      else -> Color(0xFF84A955)
    }

    drawCircle(
      color = skinColor,
      radius = headRadius,
      center = Offset(cx, headCenterY)
    )
    drawCircle(
      color = Color(0xFF263818),
      radius = headRadius,
      center = Offset(cx, headCenterY),
      style = Stroke(width = 2.5f)
    )

    drawArc(
      color = if (zombie.type == ZombieType.NECRO_SHAMAN) Color(0xFF581C87) else Color(0xFF273620),
      startAngle = 190f,
      sweepAngle = 160f,
      useCenter = true,
      topLeft = Offset(cx - headRadius, headCenterY - headRadius * 1.04f),
      size = Size(headRadius * 2f, headRadius * 1.3f)
    )

    if (zombie.type == ZombieType.CONEHEAD) {
      val conePath = Path().apply {
        moveTo(cx, headCenterY - headRadius * 1.65f)
        lineTo(cx - headRadius * 0.75f, headCenterY - headRadius * 0.45f)
        lineTo(cx + headRadius * 0.75f, headCenterY - headRadius * 0.45f)
        close()
      }
      drawPath(conePath, color = Color(0xFFF97316))
      drawPath(conePath, color = Color.Black, style = Stroke(width = 2.5f))
    } else if (zombie.type == ZombieType.SHIELD_BRUTE) {
      drawRoundRect(
        color = Color(0xFF64748B),
        topLeft = Offset(cx - bodyW * 0.55f, bodyTop - baseUnit * 0.04f),
        size = Size(bodyW * 1.10f, bodyH * 1.12f),
        cornerRadius = CornerRadius(6f)
      )
      drawRoundRect(
        color = Color(0xFFCBD5E1),
        topLeft = Offset(cx - bodyW * 0.42f, bodyTop + bodyH * 0.12f),
        size = Size(bodyW * 0.84f, bodyH * 0.25f),
        cornerRadius = CornerRadius(4f)
      )
      drawRoundRect(
        color = Color(0xFF0F172A),
        topLeft = Offset(cx - bodyW * 0.55f, bodyTop - baseUnit * 0.04f),
        size = Size(bodyW * 1.10f, bodyH * 1.12f),
        cornerRadius = CornerRadius(6f),
        style = Stroke(width = 2.5f)
      )
    }

    val eyeY = headCenterY - headRadius * 0.08f
    if (zombie.type == ZombieType.CYBER_JUGGERNAUT) {
      drawRoundRect(
        color = Color(0xFFEF4444),
        topLeft = Offset(cx - headRadius * 0.65f, eyeY - headRadius * 0.16f),
        size = Size(headRadius * 1.30f, headRadius * 0.32f),
        cornerRadius = CornerRadius(4f)
      )
    } else {
      val leftEyeX = cx - headRadius * 0.34f
      val rightEyeX = cx + headRadius * 0.34f
      drawCircle(color = Color.White, radius = headRadius * 0.24f, center = Offset(leftEyeX, eyeY))
      drawCircle(color = Color.White, radius = headRadius * 0.21f, center = Offset(rightEyeX, eyeY))
      drawCircle(color = Color(0xFF1E293B), radius = headRadius * 0.10f, center = Offset(leftEyeX, eyeY))
      drawCircle(color = Color(0xFF1E293B), radius = headRadius * 0.09f, center = Offset(rightEyeX, eyeY))
    }

    drawRoundRect(
      color = Color(0xFF7F1D1D),
      topLeft = Offset(cx - headRadius * 0.28f, headCenterY + headRadius * 0.24f),
      size = Size(headRadius * 0.56f, headRadius * 0.26f),
      cornerRadius = CornerRadius(headRadius * 0.1f)
    )

    val isEliteOrBoss = zombie.type != ZombieType.NORMAL && zombie.type != ZombieType.SPRINTER
    if (zombie.type == ZombieType.BOSS || (isEliteOrBoss && zombie.hp < zombie.maxHp)) {
      val barW = baseUnit * (if (zombie.type == ZombieType.BOSS) 1.15f else 0.85f)
      val barH = if (zombie.type == ZombieType.BOSS) 10f else 6f
      val hpRatio = (zombie.hp.toFloat() / zombie.maxHp.toFloat()).coerceIn(0f, 1f)
      drawRoundRect(
        color = Color(0xAA000000),
        topLeft = Offset(cx - barW / 2f, headCenterY - headRadius * 1.45f),
        size = Size(barW, barH),
        cornerRadius = CornerRadius(4f)
      )
      drawRoundRect(
        color = if (zombie.type == ZombieType.BOSS) Color(0xFFEF4444) else Color(0xFFFACC15),
        topLeft = Offset(cx - barW / 2f + 1.5f, headCenterY - headRadius * 1.45f + 1.5f),
        size = Size((barW - 3f) * hpRatio, barH - 3f),
        cornerRadius = CornerRadius(3f)
      )
    }
  }

  fun DrawScope.drawBlueBarrel(
    centerX: Float,
    centerY: Float,
    barrelW: Float,
    barrelH: Float,
    hpText: String,
    hitFlash: Float
  ) {
    val scale = 1f + hitFlash * 0.08f
    val w = barrelW * scale
    val h = barrelH * scale
    val left = centerX - w / 2f
    val top = centerY - h / 2f

    drawRoundRect(
      color = Color(0xFF3B82F6),
      topLeft = Offset(left - w * 0.08f, centerY - h * 0.22f),
      size = Size(w * 0.12f, h * 0.44f),
      cornerRadius = CornerRadius(5f)
    )

    val barrelBrush = Brush.verticalGradient(
      colors = if (hitFlash > 0.3f) {
        listOf(Color.White, Color(0xFFBAE6FD), Color(0xFF60A5FA))
      } else {
        listOf(Color(0xFF93C5FD), Color(0xFF60A5FA), Color(0xFF2563EB))
      },
      startY = top,
      endY = top + h
    )
    drawRoundRect(
      brush = barrelBrush,
      topLeft = Offset(left, top),
      size = Size(w, h),
      cornerRadius = CornerRadius(h * 0.26f)
    )

    drawRoundRect(
      color = Color(0x55FFFFFF),
      topLeft = Offset(left + w * 0.08f, top + h * 0.10f),
      size = Size(w * 0.84f, h * 0.22f),
      cornerRadius = CornerRadius(h * 0.12f)
    )

    drawRoundRect(
      color = Color(0xFF1E3A8A),
      topLeft = Offset(left, top),
      size = Size(w, h),
      cornerRadius = CornerRadius(h * 0.26f),
      style = Stroke(width = 2.5f)
    )

    val fontSize = h * 0.54f
    drawOutlinedText(
      text = hpText,
      x = centerX,
      y = centerY + fontSize * 0.35f,
      textSizePx = fontSize
    )
  }

  fun DrawScope.drawLeftBarrelWithPlant(
    barrel: LeftBarrel,
    canvasW: Float,
    canvasH: Float
  ) {
    val cx = 0.095f * canvasW
    val cy = barrel.y * canvasH
    val barrelW = canvasW * 0.155f
    val barrelH = canvasH * 0.056f

    val badgeCenterY = cy - barrelH * 0.80f
    val badgeRadius = barrelW * 0.35f
    drawPlantIconBadge(
      plantType = barrel.plantType,
      cx = cx,
      cy = badgeCenterY,
      radius = badgeRadius
    )

    drawBlueBarrel(
      centerX = cx,
      centerY = cy,
      barrelW = barrelW,
      barrelH = barrelH,
      hpText = barrel.hp.toString(),
      hitFlash = barrel.hitFlash
    )

    // Short tactical label above the barrel number
    val shortLabel = when (barrel.plantType) {
      PlantType.SPIDER_SHOOTER -> "Паучок"
      PlantType.SAWBLADE_ROLLER -> "Каток ⚙️"
      PlantType.MINEFIELD_TRAP -> "Мины 🧨"
      PlantType.EGGPLANT_MORTAR -> "Мортира"
      PlantType.TESLA_COIL -> "Тесла ⚡"
      PlantType.NAPALM_BARRAGE -> "Напалм 🔥"
      PlantType.ANGRY_FLOWER -> "Лазер 🌻"
      PlantType.FROST_CACTUS -> "Крио ❄️"
    }
    drawOutlinedText(
      text = shortLabel,
      x = cx,
      y = cy - barrelH * 0.32f,
      textSizePx = barrelH * 0.35f
    )
  }

  fun DrawScope.drawPlantIconBadge(
    plantType: PlantType,
    cx: Float,
    cy: Float,
    radius: Float,
    levelBadge: Int? = null
  ) {
    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(Color(0xFFFEF08A), Color(0xFFFACC15), Color(0xFFEAB308)),
        center = Offset(cx, cy),
        radius = radius
      ),
      radius = radius,
      center = Offset(cx, cy)
    )
    drawCircle(
      color = Color(0xFFFEF9C3),
      radius = radius,
      center = Offset(cx, cy),
      style = Stroke(width = 3f)
    )

    when (plantType) {
      PlantType.SAWBLADE_ROLLER -> {
        // Steel circular sawblade with teeth
        drawCircle(color = Color(0xFF94A3B8), radius = radius * 0.68f, center = Offset(cx, cy))
        drawCircle(color = Color(0xFF1E293B), radius = radius * 0.68f, center = Offset(cx, cy), style = Stroke(width = 3f))
        drawCircle(color = Color(0xFFEF4444), radius = radius * 0.25f, center = Offset(cx, cy))
      }

      PlantType.MINEFIELD_TRAP -> {
        // High-explosive landmine with blinking red detonator
        drawOval(
          color = Color(0xFF334155),
          topLeft = Offset(cx - radius * 0.65f, cy - radius * 0.35f),
          size = Size(radius * 1.30f, radius * 0.75f)
        )
        drawCircle(color = Color(0xFFEF4444), radius = radius * 0.26f, center = Offset(cx, cy - radius * 0.15f))
        drawCircle(color = Color.White, radius = radius * 0.10f, center = Offset(cx, cy - radius * 0.15f))
      }

      PlantType.TESLA_COIL -> {
        // Electric Tesla Tower with cyan lightning orb
        drawRoundRect(
          color = Color(0xFF475569),
          topLeft = Offset(cx - radius * 0.30f, cy - radius * 0.20f),
          size = Size(radius * 0.60f, radius * 0.75f),
          cornerRadius = CornerRadius(4f)
        )
        drawCircle(color = Color(0xFF38BDF8), radius = radius * 0.42f, center = Offset(cx, cy - radius * 0.32f))
        drawCircle(color = Color.White, radius = radius * 0.20f, center = Offset(cx, cy - radius * 0.32f))
      }

      PlantType.NAPALM_BARRAGE -> {
        // Fiery Napalm Warhead
        drawCircle(color = Color(0xFFDC2626), radius = radius * 0.62f, center = Offset(cx, cy))
        drawCircle(color = Color(0xFFF97316), radius = radius * 0.42f, center = Offset(cx, cy + radius * 0.08f))
        drawCircle(color = Color(0xFFFDE047), radius = radius * 0.22f, center = Offset(cx, cy + radius * 0.14f))
      }

      else -> {
        // Terracotta pot for plant turrets
        val potW = radius * 0.75f
        val potH = radius * 0.45f
        val potTop = cy + radius * 0.25f
        drawRoundRect(
          color = Color(0xFFC2410C),
          topLeft = Offset(cx - potW / 2f, potTop),
          size = Size(potW, potH),
          cornerRadius = CornerRadius(6f)
        )

        when (plantType) {
          PlantType.SPIDER_SHOOTER -> {
            drawCircle(color = Color(0xFF4ADE80), radius = radius * 0.42f, center = Offset(cx, cy - radius * 0.14f))
            drawCircle(color = Color.White, radius = radius * 0.13f, center = Offset(cx - radius * 0.15f, cy - radius * 0.18f))
            drawCircle(color = Color.White, radius = radius * 0.13f, center = Offset(cx + radius * 0.15f, cy - radius * 0.18f))
            drawCircle(color = Color.Black, radius = radius * 0.07f, center = Offset(cx - radius * 0.15f, cy - radius * 0.18f))
            drawCircle(color = Color.Black, radius = radius * 0.07f, center = Offset(cx + radius * 0.15f, cy - radius * 0.18f))
          }
          PlantType.EGGPLANT_MORTAR -> {
            drawOval(
              color = Color(0xFF9333EA),
              topLeft = Offset(cx - radius * 0.44f, cy - radius * 0.65f),
              size = Size(radius * 0.88f, radius * 0.96f)
            )
            drawOval(
              color = Color(0xFF22C55E),
              topLeft = Offset(cx - radius * 0.36f, cy - radius * 0.78f),
              size = Size(radius * 0.72f, radius * 0.32f)
            )
          }
          PlantType.ANGRY_FLOWER -> {
            for (i in 0 until 8) {
              val angle = i * (Math.PI / 4.0)
              val px = cx + cos(angle).toFloat() * radius * 0.42f
              val py = (cy - radius * 0.18f) + sin(angle).toFloat() * radius * 0.42f
              drawCircle(color = Color.White, radius = radius * 0.22f, center = Offset(px, py))
            }
            drawCircle(color = Color(0xFFF97316), radius = radius * 0.34f, center = Offset(cx, cy - radius * 0.18f))
          }
          else -> {
            drawCircle(color = Color(0xFF0284C7), radius = radius * 0.44f, center = Offset(cx, cy - radius * 0.18f))
            drawCircle(color = Color(0xFFBAE6FD), radius = radius * 0.28f, center = Offset(cx, cy - radius * 0.18f))
          }
        }
      }
    }

    if (levelBadge != null) {
      drawOutlinedText(
        text = "Lv.$levelBadge",
        x = cx,
        y = cy + radius * 0.85f,
        textSizePx = radius * 0.48f,
        fillColor = android.graphics.Color.rgb(134, 239, 172)
      )
    }
  }

  fun DrawScope.drawActiveTurret(
    turret: ActiveTurret,
    canvasW: Float,
    canvasH: Float
  ) {
    val cx = 0.185f * canvasW + turret.recoilAnim * 6f
    val cy = turret.y * canvasH
    val radius = canvasW * 0.048f
    drawPlantIconBadge(
      plantType = turret.plantType,
      cx = cx,
      cy = cy,
      radius = radius,
      levelBadge = turret.level
    )
  }

  fun DrawScope.drawBridgeMineItem(mine: BridgeMine, canvasW: Float, canvasH: Float) {
    val cx = mine.x * canvasW
    val cy = mine.y * canvasH
    val r = canvasW * 0.028f
    drawCircle(color = Color(0xFF1E293B), radius = r, center = Offset(cx, cy))
    drawCircle(color = Color(0xFF94A3B8), radius = r, center = Offset(cx, cy), style = Stroke(width = 2.5f))
    drawCircle(color = Color(0xFFEF4444), radius = r * 0.45f, center = Offset(cx, cy))
  }

  fun DrawScope.drawSawbladeItem(blade: SawbladeWave, canvasW: Float, canvasH: Float) {
    val cx = blade.x * canvasW
    val cy = blade.y * canvasH
    val r = canvasW * 0.058f
    // Outer spinning teeth ring
    for (i in 0 until 8) {
      val angle = Math.toRadians((blade.rotation + i * 45f).toDouble())
      val tx = cx + cos(angle).toFloat() * r * 1.15f
      val ty = cy + sin(angle).toFloat() * r * 1.15f
      drawCircle(color = Color(0xFFE2E8F0), radius = r * 0.25f, center = Offset(tx, ty))
    }
    drawCircle(color = Color(0xFF64748B), radius = r, center = Offset(cx, cy))
    drawCircle(color = Color(0xFF0F172A), radius = r, center = Offset(cx, cy), style = Stroke(width = 3f))
    drawCircle(color = Color(0xFFEF4444), radius = r * 0.35f, center = Offset(cx, cy))
  }

  fun DrawScope.drawFallingBuffDrop(drop: FallingBuffDrop, canvasW: Float, canvasH: Float) {
    val swayX = sin(drop.swayPhase) * canvasW * 0.015f
    val cx = (drop.x * canvasW + swayX).coerceIn(canvasW * 0.08f, canvasW * 0.92f)
    val cy = drop.y * canvasH
    val r = canvasW * 0.048f
    val mainColor = Color(drop.type.colorHex)

    // Parachute canopy above the buff crate!
    drawArc(
      color = Color(0xFFF8FAFC),
      startAngle = 180f,
      sweepAngle = 180f,
      useCenter = true,
      topLeft = Offset(cx - r * 1.15f, cy - r * 1.95f),
      size = Size(r * 2.30f, r * 1.3f)
    )
    drawLine(
      color = Color(0xFFCBD5E1),
      start = Offset(cx - r * 0.9f, cy - r * 1.3f),
      end = Offset(cx - r * 0.4f, cy - r * 0.4f),
      strokeWidth = 2f
    )
    drawLine(
      color = Color(0xFFCBD5E1),
      start = Offset(cx + r * 0.9f, cy - r * 1.3f),
      end = Offset(cx + r * 0.4f, cy - r * 0.4f),
      strokeWidth = 2f
    )

    // Glowing Buff Capsule Crate
    drawCircle(
      color = mainColor.copy(alpha = 0.32f),
      radius = r * 1.35f,
      center = Offset(cx, cy)
    )
    drawRoundRect(
      color = mainColor,
      topLeft = Offset(cx - r * 0.85f, cy - r * 0.65f),
      size = Size(r * 1.70f, r * 1.30f),
      cornerRadius = CornerRadius(12f)
    )
    drawRoundRect(
      color = Color.White,
      topLeft = Offset(cx - r * 0.85f, cy - r * 0.65f),
      size = Size(r * 1.70f, r * 1.30f),
      cornerRadius = CornerRadius(12f),
      style = Stroke(width = 3f)
    )

    drawOutlinedText(
      text = drop.type.shortTagRu,
      x = cx,
      y = cy + r * 0.18f,
      textSizePx = r * 0.50f
    )
  }

  fun DrawScope.drawRightBarrelWithUpgrade(
    barrel: RightBarrel,
    canvasW: Float,
    canvasH: Float
  ) {
    val cx = 0.905f * canvasW
    val cy = barrel.y * canvasH
    val barrelW = canvasW * 0.155f
    val barrelH = canvasH * 0.056f

    val badgeCenterY = cy - barrelH * 0.82f
    val badgeRadius = barrelW * 0.34f

    drawCircle(
      brush = Brush.radialGradient(
        colors = listOf(Color(0xFFFEF08A), Color(0xFFFACC15), Color(0xFFD97706)),
        center = Offset(cx, badgeCenterY),
        radius = badgeRadius
      ),
      radius = badgeRadius,
      center = Offset(cx, badgeCenterY)
    )
    drawCircle(
      color = Color(0xFFFEF9C3),
      radius = badgeRadius,
      center = Offset(cx, badgeCenterY),
      style = Stroke(width = 2.5f)
    )

    when (barrel.upgradeType) {
      UpgradeType.FIRE_RATE_BOOST, UpgradeType.ATTACK_BOOST -> {
        val burstColor = if (barrel.upgradeType == UpgradeType.ATTACK_BOOST) Color(0xFFDC2626) else Color(0xFFF97316)
        drawCircle(color = burstColor, radius = badgeRadius * 0.65f, center = Offset(cx, badgeCenterY))
        val bladePath = Path().apply {
          moveTo(cx + badgeRadius * 0.45f, badgeCenterY - badgeRadius * 0.45f)
          lineTo(cx + badgeRadius * 0.15f, badgeCenterY - badgeRadius * 0.40f)
          lineTo(cx - badgeRadius * 0.35f, badgeCenterY + badgeRadius * 0.15f)
          lineTo(cx - badgeRadius * 0.15f, badgeCenterY + badgeRadius * 0.35f)
          lineTo(cx + badgeRadius * 0.40f, badgeCenterY - badgeRadius * 0.15f)
          close()
        }
        drawPath(bladePath, color = Color(0xFFE2E8F0))
        drawPath(bladePath, color = Color.Black, style = Stroke(width = 2f))
      }

      UpgradeType.BULLETS_PLUS_1 -> {
        drawRoundRect(
          color = Color(0xFFF59E0B),
          topLeft = Offset(cx - badgeRadius * 0.28f, badgeCenterY - badgeRadius * 0.15f),
          size = Size(badgeRadius * 0.56f, badgeRadius * 0.55f),
          cornerRadius = CornerRadius(6f)
        )
        drawArc(
          color = Color(0xFF2563EB),
          startAngle = 180f,
          sweepAngle = 180f,
          useCenter = true,
          topLeft = Offset(cx - badgeRadius * 0.28f, badgeCenterY - badgeRadius * 0.55f),
          size = Size(badgeRadius * 0.56f, badgeRadius * 0.75f)
        )
      }

      UpgradeType.HERO_PLUS_1 -> {
        drawOval(
          color = Color(0xFFA16236),
          topLeft = Offset(cx - badgeRadius * 0.52f, badgeCenterY - badgeRadius * 0.32f),
          size = Size(badgeRadius * 1.04f, badgeRadius * 0.72f)
        )
        drawOval(
          color = Color(0xFFD97706),
          topLeft = Offset(cx - badgeRadius * 0.72f, badgeCenterY - badgeRadius * 0.48f),
          size = Size(badgeRadius * 1.44f, badgeRadius * 0.32f)
        )
      }
    }

    drawBlueBarrel(
      centerX = cx,
      centerY = cy,
      barrelW = barrelW,
      barrelH = barrelH,
      hpText = barrel.hp.toString(),
      hitFlash = barrel.hitFlash
    )

    val labelText = when (barrel.upgradeType) {
      UpgradeType.ATTACK_BOOST -> "Урон +${barrel.bonusAmount}%"
      UpgradeType.BULLETS_PLUS_1 -> "Стволы +1"
      UpgradeType.FIRE_RATE_BOOST -> "Темп +${barrel.bonusAmount}%"
      UpgradeType.HERO_PLUS_1 -> "Отряд +1"
    }
    drawOutlinedText(
      text = labelText,
      x = cx,
      y = cy - barrelH * 0.34f,
      textSizePx = barrelH * 0.35f,
      fillColor = android.graphics.Color.WHITE
    )
  }

  fun DrawScope.drawCapybaraCrocodileSquad(
    playerX: Float,
    squadCount: Int,
    muzzleFlash: Float,
    canvasW: Float,
    canvasH: Float,
    overdriveActive: Boolean = false
  ) {
    val baseCenterX = playerX * canvasW
    val baseCenterY = 0.79f * canvasH
    val unitSize = canvasW * 0.115f

    if (overdriveActive) {
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(Color(0x66FACC15), Color(0x22EF4444), Color.Transparent),
          center = Offset(baseCenterX, baseCenterY),
          radius = unitSize * 1.45f
        ),
        radius = unitSize * 1.45f,
        center = Offset(baseCenterX, baseCenterY)
      )
    }

    // Render up to 10 visible Crocodile Riders in formation!
    val visibleCount = squadCount.coerceIn(1, 10)
    val offsets = listOf(
      Offset(0.0f, -0.18f),
      Offset(-0.42f, 0.12f),
      Offset(0.42f, 0.12f),
      Offset(-0.24f, -0.32f),
      Offset(0.24f, -0.32f),
      Offset(-0.68f, 0.22f),
      Offset(0.68f, 0.22f),
      Offset(0.0f, 0.24f),
      Offset(-0.52f, -0.18f),
      Offset(0.52f, -0.18f)
    )

    for (i in (visibleCount - 1) downTo 0) {
      val off = offsets[i]
      val ux = (baseCenterX + off.x * unitSize).coerceIn(unitSize * 0.40f, canvasW - unitSize * 0.40f)
      val uy = baseCenterY + off.y * unitSize
      drawSingleCapybaraOnCrocodile(
        cx = ux,
        cy = uy,
        unitSize = unitSize * (if (i == 0) 1.06f else 0.88f),
        muzzleFlash = muzzleFlash
      )
    }

    // Show unlimited squad counter badge right below the lead Capybara!
    if (squadCount > 2) {
      drawOutlinedText(
        text = "x$squadCount КАПИБАР",
        x = baseCenterX,
        y = baseCenterY + unitSize * 0.65f,
        textSizePx = canvasW * 0.032f,
        fillColor = android.graphics.Color.rgb(134, 239, 172)
      )
    }
  }

  private fun DrawScope.drawSingleCapybaraOnCrocodile(
    cx: Float,
    cy: Float,
    unitSize: Float,
    muzzleFlash: Float
  ) {
    drawOval(
      color = Color(0x44000000),
      topLeft = Offset(cx - unitSize * 0.48f, cy + unitSize * 0.26f),
      size = Size(unitSize * 0.96f, unitSize * 0.24f)
    )

    drawRoundRect(
      color = Color(0xFF65A30D),
      topLeft = Offset(cx - unitSize * 0.45f, cy + unitSize * 0.02f),
      size = Size(unitSize * 0.90f, unitSize * 0.36f),
      cornerRadius = CornerRadius(unitSize * 0.16f)
    )
    drawRoundRect(
      color = Color(0xFF365314),
      topLeft = Offset(cx - unitSize * 0.45f, cy + unitSize * 0.02f),
      size = Size(unitSize * 0.90f, unitSize * 0.36f),
      cornerRadius = CornerRadius(unitSize * 0.16f),
      style = Stroke(width = 2.5f)
    )
    drawRoundRect(
      color = Color(0xFFECFCCB),
      topLeft = Offset(cx - unitSize * 0.35f, cy + unitSize * 0.22f),
      size = Size(unitSize * 0.70f, unitSize * 0.12f),
      cornerRadius = CornerRadius(6f)
    )

    val capyW = unitSize * 0.52f
    val capyH = unitSize * 0.48f
    val capyTop = cy - unitSize * 0.36f
    drawOval(
      color = Color(0xFF9A5B32),
      topLeft = Offset(cx - capyW / 2f, capyTop),
      size = Size(capyW, capyH)
    )
    drawOval(
      color = Color(0xFF431407),
      topLeft = Offset(cx - capyW / 2f, capyTop),
      size = Size(capyW, capyH),
      style = Stroke(width = 2.5f)
    )

    drawRoundRect(
      color = Color(0xFFDC2626),
      topLeft = Offset(cx - capyW * 0.44f, cy - unitSize * 0.02f),
      size = Size(capyW * 0.88f, unitSize * 0.13f),
      cornerRadius = CornerRadius(6f)
    )

    drawOval(
      color = Color(0xFFB45309),
      topLeft = Offset(cx - capyW * 0.72f, capyTop - unitSize * 0.06f),
      size = Size(capyW * 1.44f, unitSize * 0.18f)
    )
    drawRoundRect(
      color = Color(0xFF92400E),
      topLeft = Offset(cx - capyW * 0.42f, capyTop - unitSize * 0.22f),
      size = Size(capyW * 0.84f, unitSize * 0.18f),
      cornerRadius = CornerRadius(8f)
    )

    val gunX = cx + unitSize * 0.24f
    val gunTop = cy - unitSize * 0.42f
    val gunW = unitSize * 0.22f
    val gunH = unitSize * 0.46f
    drawRoundRect(
      color = Color(0xFF1E293B),
      topLeft = Offset(gunX, gunTop),
      size = Size(gunW, gunH),
      cornerRadius = CornerRadius(4f)
    )
    drawRoundRect(
      color = Color(0xFF64748B),
      topLeft = Offset(gunX + gunW * 0.2f, gunTop + 4f),
      size = Size(gunW * 0.6f, gunH * 0.5f),
      cornerRadius = CornerRadius(2f)
    )

    if (muzzleFlash > 0.1f) {
      val flashR = unitSize * 0.24f * muzzleFlash
      drawCircle(
        brush = Brush.radialGradient(
          colors = listOf(Color.White, Color(0xFFFDE047), Color(0x00F97316)),
          center = Offset(gunX + gunW / 2f, gunTop - flashR * 0.3f),
          radius = flashR
        ),
        radius = flashR,
        center = Offset(gunX + gunW / 2f, gunTop - flashR * 0.3f)
      )
    }
  }
}
