package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.audio.SoundAndHapticsManager
import com.example.data.GamePreferencesRepository
import com.example.model.AchievementDef
import com.example.model.ActiveTurret
import com.example.model.AppScreen
import com.example.model.BridgeGameUiState
import com.example.model.BridgeMine
import com.example.model.DropBuffType
import com.example.model.FallingBuffDrop
import com.example.model.FloatingText
import com.example.model.GameMode
import com.example.model.GameStatus
import com.example.model.Lane
import com.example.model.LeftBarrel
import com.example.model.PermanentUpgrades
import com.example.model.PlantType
import com.example.model.Projectile
import com.example.model.ProjectileStyle
import com.example.model.RightBarrel
import com.example.model.SawbladeWave
import com.example.model.UpgradeType
import com.example.model.VisualParticle
import com.example.model.Zombie
import com.example.model.ZombieType
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.random.Random

class BridgeGameViewModel(
  private val repository: GamePreferencesRepository,
  private val soundManager: SoundAndHapticsManager
) : ViewModel() {

  private val _uiState = MutableStateFlow(BridgeGameUiState())
  val uiState: StateFlow<BridgeGameUiState> = _uiState.asStateFlow()

  private var nextEntityId = 100L
  private var shootAccumulator = 0f
  private var zombieRowSpawnAccumulator = 0f
  private var buffDropSpawnAccumulator = 0f
  private var zombieRowCounter = 0
  private var bossSpawnedForWave = false
  private var leftBarrelsBrokenInRun = 0
  private var rightBarrelsBrokenInRun = 0

  init {
    val savedUpgrades = repository.loadUpgrades()
    val savedStats = repository.loadStats()
    _uiState.update {
      it.copy(
        currentScreen = AppScreen.MAIN_MENU,
        waveNumber = savedUpgrades.unlockedWave,
        permanentUpgrades = savedUpgrades,
        playerStats = savedStats
      )
    }
    startGameLoop()
  }

  private fun nextId(): Long = ++nextEntityId

  fun getAchievements(): List<AchievementDef> {
    val s = _uiState.value
    return repository.buildAchievementsList(s.playerStats, s.permanentUpgrades)
  }

  fun claimAchievement(achievementId: String) {
    val current = _uiState.value
    val list = repository.buildAchievementsList(current.playerStats, current.permanentUpgrades)
    val target = list.find { it.id == achievementId } ?: return
    if (!target.isCompleted || target.isClaimed) return

    val updatedStats = current.playerStats.copy(
      claimedAchievementIds = current.playerStats.claimedAchievementIds + achievementId,
      lifetimeCrystalsEarned = current.playerStats.lifetimeCrystalsEarned + target.rewardCrystals
    )
    val updatedPerm = current.permanentUpgrades.copy(
      crystals = current.permanentUpgrades.crystals + target.rewardCrystals
    )
    repository.saveStats(updatedStats)
    repository.saveUpgrades(updatedPerm)
    soundManager.playWaveVictory(updatedPerm.soundEnabled, updatedPerm.hapticsEnabled)

    _uiState.update {
      it.copy(
        permanentUpgrades = updatedPerm,
        playerStats = updatedStats
      )
    }
  }

  fun openMainMenu() {
    _uiState.update {
      it.copy(
        currentScreen = AppScreen.MAIN_MENU,
        status = GameStatus.PAUSED,
        showArmorySheet = false,
        showStatsSheet = false,
        showCompendiumSheet = false,
        showSettingsSheet = false
      )
    }
  }

  fun startNewRun(mode: GameMode) {
    val updatedStats = _uiState.value.playerStats.copy(
      totalRunsPlayed = _uiState.value.playerStats.totalRunsPlayed + 1
    )
    repository.saveStats(updatedStats)
    _uiState.update {
      it.copy(
        currentScreen = AppScreen.GAMEPLAY,
        gameMode = mode,
        playerStats = updatedStats,
        showArmorySheet = false,
        showStatsSheet = false,
        showCompendiumSheet = false,
        showSettingsSheet = false
      )
    }
    startWave(
      wave = if (mode == GameMode.ENDLESS) 1 else _uiState.value.permanentUpgrades.unlockedWave,
      mode = mode,
      savedUpgrades = _uiState.value.permanentUpgrades
    )
  }

  fun startWave(
    wave: Int = _uiState.value.waveNumber,
    mode: GameMode = _uiState.value.gameMode,
    savedUpgrades: PermanentUpgrades = _uiState.value.permanentUpgrades
  ) {
    shootAccumulator = 0f
    zombieRowSpawnAccumulator = 0f
    buffDropSpawnAccumulator = 3.5f
    zombieRowCounter = 0
    bossSpawnedForWave = false
    leftBarrelsBrokenInRun = 0
    rightBarrelsBrokenInRun = 0

    val initialLeftBarrels = listOf(
      LeftBarrel(
        id = nextId(),
        y = 0.44f,
        hp = PlantType.SPIDER_SHOOTER.baseHitsRequired,
        maxHp = PlantType.SPIDER_SHOOTER.baseHitsRequired,
        plantType = PlantType.SPIDER_SHOOTER
      ),
      LeftBarrel(
        id = nextId(),
        y = 0.29f,
        hp = PlantType.SAWBLADE_ROLLER.baseHitsRequired,
        maxHp = PlantType.SAWBLADE_ROLLER.baseHitsRequired,
        plantType = PlantType.SAWBLADE_ROLLER
      ),
      LeftBarrel(
        id = nextId(),
        y = 0.15f,
        hp = PlantType.MINEFIELD_TRAP.baseHitsRequired,
        maxHp = PlantType.MINEFIELD_TRAP.baseHitsRequired,
        plantType = PlantType.MINEFIELD_TRAP
      )
    )

    val initialRightBarrels = listOf(
      RightBarrel(
        id = nextId(),
        y = 0.45f,
        hp = UpgradeType.FIRE_RATE_BOOST.baseHitsRequired,
        maxHp = UpgradeType.FIRE_RATE_BOOST.baseHitsRequired,
        upgradeType = UpgradeType.FIRE_RATE_BOOST,
        bonusAmount = 18
      ),
      RightBarrel(
        id = nextId(),
        y = 0.33f,
        hp = UpgradeType.ATTACK_BOOST.baseHitsRequired,
        maxHp = UpgradeType.ATTACK_BOOST.baseHitsRequired,
        upgradeType = UpgradeType.ATTACK_BOOST,
        bonusAmount = 25
      ),
      RightBarrel(
        id = nextId(),
        y = 0.21f,
        hp = UpgradeType.BULLETS_PLUS_1.baseHitsRequired,
        maxHp = UpgradeType.BULLETS_PLUS_1.baseHitsRequired,
        upgradeType = UpgradeType.BULLETS_PLUS_1,
        bonusAmount = 1
      ),
      RightBarrel(
        id = nextId(),
        y = 0.09f,
        hp = UpgradeType.HERO_PLUS_1.baseHitsRequired,
        maxHp = UpgradeType.HERO_PLUS_1.baseHitsRequired,
        upgradeType = UpgradeType.HERO_PLUS_1,
        bonusAmount = 1
      )
    )

    val initialThreat = if (mode == GameMode.ENDLESS) 1 else wave
    val initialZombies = mutableListOf<Zombie>()
    val startRows = 4
    for (r in 0 until startRows) {
      val rowY = 0.22f - r * 0.055f
      initialZombies += createZombieRow(
        rowY = rowY,
        threatLevel = initialThreat,
        rowNumber = r
      )
    }
    zombieRowCounter = startRows

    val totalWaveZombies = if (mode == GameMode.ENDLESS) 999999 else (95 + wave * 30)

    _uiState.update { current ->
      current.copy(
        currentScreen = AppScreen.GAMEPLAY,
        gameMode = mode,
        waveNumber = wave,
        endlessThreatLevel = initialThreat,
        endlessElapsedSec = 0f,
        runGoldEarned = 0,
        runCrystalsEarned = 0,
        status = GameStatus.PLAYING,
        playerX = 0.50f,
        squadCount = 2,
        bulletStreams = 2,
        bulletDamage = savedUpgrades.startingBulletDamage,
        fireRateMultiplier = savedUpgrades.startingFireRateMultiplier,
        overdriveTimer = 0f,
        leftGateMultiplier = savedUpgrades.leftMultiplier,
        rightGateMultiplier = savedUpgrades.rightMultiplier,
        baseHp = savedUpgrades.startingMaxBaseHp,
        maxBaseHp = savedUpgrades.startingMaxBaseHp,
        score = 0,
        zombiesRemainingInWave = totalWaveZombies,
        totalZombiesInWave = totalWaveZombies,
        zombiesKilledInRun = 0,
        leftBarrels = initialLeftBarrels,
        activeTurrets = emptyList(),
        rightBarrels = initialRightBarrels,
        fallingBuffs = emptyList(),
        bridgeMines = emptyList(),
        sawblades = emptyList(),
        zombies = initialZombies,
        projectiles = emptyList(),
        floatingTexts = emptyList(),
        particles = emptyList(),
        permanentUpgrades = savedUpgrades,
        dangerFlashIntensity = 0f
      )
    }
  }

  private fun createZombieRow(
    rowY: Float,
    threatLevel: Int,
    rowNumber: Int
  ): List<Zombie> {
    // 8 columns across the wide Center Bridge (x = 0.21f .. 0.79f)!
    val cols = 8
    val rowList = mutableListOf<Zombie>()
    val baseHp = (70f * (1.22f).pow((threatLevel - 1).coerceAtMost(35)) +
      (threatLevel - 1) * 38f + (rowNumber.coerceAtMost(20)) * 3f).roundToInt()

    val eligibleTypes = ZombieType.entries.filter {
      it != ZombieType.BOSS && it.minThreatLevel <= threatLevel
    }

    for (col in 0 until cols) {
      val normalizedCol = (col + 0.5f) / cols
      val jitterX = (Random.nextFloat() - 0.5f) * 0.014f
      val x = (0.215f + normalizedCol * 0.57f + jitterX).coerceIn(0.21f, 0.79f)

      val roll = Random.nextFloat()
      val specialChance = (0.10f + (threatLevel - 1) * 0.045f).coerceAtMost(0.60f)
      val chosenType = if (threatLevel > 1 && roll < specialChance && eligibleTypes.size > 1) {
        eligibleTypes.filter { it != ZombieType.NORMAL }.random()
      } else {
        ZombieType.NORMAL
      }

      val hp = (baseHp * chosenType.hpMultiplier).roundToInt().coerceAtLeast(50)
      rowList += Zombie(
        id = nextId(),
        x = x,
        y = rowY + (col % 2) * 0.006f,
        rowId = rowNumber,
        colIndex = col,
        hp = hp,
        maxHp = hp,
        type = chosenType,
        walkPhase = Random.nextFloat() * 6.28f
      )
    }
    return rowList
  }

  fun setPlayerHorizontalPosition(normalizedX: Float) {
    val clamped = normalizedX.coerceIn(0.07f, 0.93f)
    _uiState.update { it.copy(playerX = clamped, autoPilotEnabled = false) }
  }

  fun snapToLane(lane: Lane) {
    val targetX = when (lane) {
      Lane.LEFT -> 0.095f
      Lane.CENTER -> 0.50f
      Lane.RIGHT -> 0.905f
    }
    _uiState.update { it.copy(playerX = targetX, autoPilotEnabled = false) }
  }

  fun togglePause() {
    _uiState.update { state ->
      val next = when (state.status) {
        GameStatus.PLAYING -> GameStatus.PAUSED
        GameStatus.PAUSED -> GameStatus.PLAYING
        else -> state.status
      }
      state.copy(status = next)
    }
  }

  fun toggleGameSpeed() {
    _uiState.update { state ->
      val nextSpeed = if (state.gameSpeedMultiplier < 1.3f) 1.5f else 1.0f
      state.copy(gameSpeedMultiplier = nextSpeed)
    }
  }

  fun toggleAutoPilot() {
    _uiState.update { it.copy(autoPilotEnabled = !it.autoPilotEnabled) }
  }

  fun setShowArmory(show: Boolean) {
    _uiState.update { state ->
      val pausedStatus = if (show && state.currentScreen == AppScreen.GAMEPLAY && state.status == GameStatus.PLAYING) {
        GameStatus.PAUSED
      } else if (!show && state.currentScreen == AppScreen.GAMEPLAY && state.status == GameStatus.PAUSED &&
        !state.showCompendiumSheet && !state.showStatsSheet && !state.showSettingsSheet
      ) {
        GameStatus.PLAYING
      } else {
        state.status
      }
      state.copy(showArmorySheet = show, status = pausedStatus)
    }
  }

  fun setShowStats(show: Boolean) {
    _uiState.update { state ->
      val pausedStatus = if (show && state.currentScreen == AppScreen.GAMEPLAY && state.status == GameStatus.PLAYING) {
        GameStatus.PAUSED
      } else if (!show && state.currentScreen == AppScreen.GAMEPLAY && state.status == GameStatus.PAUSED &&
        !state.showArmorySheet && !state.showCompendiumSheet && !state.showSettingsSheet
      ) {
        GameStatus.PLAYING
      } else {
        state.status
      }
      state.copy(showStatsSheet = show, status = pausedStatus)
    }
  }

  fun setShowCompendium(show: Boolean) {
    _uiState.update { state ->
      val pausedStatus = if (show && state.currentScreen == AppScreen.GAMEPLAY && state.status == GameStatus.PLAYING) {
        GameStatus.PAUSED
      } else if (!show && state.currentScreen == AppScreen.GAMEPLAY && state.status == GameStatus.PAUSED &&
        !state.showArmorySheet && !state.showStatsSheet && !state.showSettingsSheet
      ) {
        GameStatus.PLAYING
      } else {
        state.status
      }
      state.copy(showCompendiumSheet = show, status = pausedStatus)
    }
  }

  fun setShowSettings(show: Boolean) {
    _uiState.update { state ->
      val pausedStatus = if (show && state.currentScreen == AppScreen.GAMEPLAY && state.status == GameStatus.PLAYING) {
        GameStatus.PAUSED
      } else if (!show && state.currentScreen == AppScreen.GAMEPLAY && state.status == GameStatus.PAUSED &&
        !state.showArmorySheet && !state.showStatsSheet && !state.showCompendiumSheet
      ) {
        GameStatus.PLAYING
      } else {
        state.status
      }
      state.copy(showSettingsSheet = show, status = pausedStatus)
    }
  }

  fun toggleSound() {
    _uiState.update { state ->
      val updated = state.permanentUpgrades.copy(soundEnabled = !state.permanentUpgrades.soundEnabled)
      repository.saveUpgrades(updated)
      state.copy(permanentUpgrades = updated)
    }
  }

  fun toggleHaptics() {
    _uiState.update { state ->
      val updated = state.permanentUpgrades.copy(hapticsEnabled = !state.permanentUpgrades.hapticsEnabled)
      repository.saveUpgrades(updated)
      state.copy(permanentUpgrades = updated)
    }
  }

  fun buyPermanentUpgrade(type: String) {
    _uiState.update { state ->
      val perm = state.permanentUpgrades
      val updated = when (type) {
        "gold_damage" -> {
          val cost = 80 + (perm.baseDamageLevel - 1) * 65
          if (perm.gold >= cost) {
            perm.copy(gold = perm.gold - cost, baseDamageLevel = perm.baseDamageLevel + 1)
          } else perm
        }
        "gold_firerate" -> {
          val cost = 95 + (perm.baseFireRateLevel - 1) * 75
          if (perm.gold >= cost && perm.baseFireRateLevel < 15) {
            perm.copy(gold = perm.gold - cost, baseFireRateLevel = perm.baseFireRateLevel + 1)
          } else perm
        }
        "gold_fortress" -> {
          val cost = 90 + (perm.baseFortressHpLevel - 1) * 70
          if (perm.gold >= cost && perm.baseFortressHpLevel < 15) {
            perm.copy(gold = perm.gold - cost, baseFortressHpLevel = perm.baseFortressHpLevel + 1)
          } else perm
        }
        "crystal_power" -> {
          val cost = 15 + perm.crystalPowerLevel * 12
          if (perm.crystals >= cost) {
            perm.copy(crystals = perm.crystals - cost, crystalPowerLevel = perm.crystalPowerLevel + 1)
          } else perm
        }
        "crystal_crit" -> {
          val cost = 18 + perm.crystalCritLevel * 14
          if (perm.crystals >= cost && perm.crystalCritLevel < 10) {
            perm.copy(crystals = perm.crystals - cost, crystalCritLevel = perm.crystalCritLevel + 1)
          } else perm
        }
        "crystal_turret" -> {
          val cost = 20 + perm.crystalTurretTechLevel * 15
          if (perm.crystals >= cost && perm.crystalTurretTechLevel < 10) {
            perm.copy(crystals = perm.crystals - cost, crystalTurretTechLevel = perm.crystalTurretTechLevel + 1)
          } else perm
        }
        "crystal_gate" -> {
          val cost = 25 + perm.crystalGateMasteryLevel * 20
          if (perm.crystals >= cost && perm.crystalGateMasteryLevel < 6) {
            perm.copy(crystals = perm.crystals - cost, crystalGateMasteryLevel = perm.crystalGateMasteryLevel + 1)
          } else perm
        }
        "crystal_bounty" -> {
          val cost = 20 + perm.crystalBountyLevel * 16
          if (perm.crystals >= cost && perm.crystalBountyLevel < 10) {
            perm.copy(crystals = perm.crystals - cost, crystalBountyLevel = perm.crystalBountyLevel + 1)
          } else perm
        }
        else -> perm
      }
      if (updated != perm) {
        repository.saveUpgrades(updated)
        soundManager.playBarrelBreak(updated.soundEnabled, updated.hapticsEnabled)
      }
      state.copy(
        permanentUpgrades = updated,
        leftGateMultiplier = updated.leftMultiplier,
        rightGateMultiplier = updated.rightMultiplier
      )
    }
  }

  fun advanceToNextWave() {
    val nextWave = _uiState.value.waveNumber + 1
    val updatedPerm = _uiState.value.permanentUpgrades.copy(
      unlockedWave = max(_uiState.value.permanentUpgrades.unlockedWave, nextWave)
    )
    val updatedStats = _uiState.value.playerStats.copy(
      highestCampaignWave = max(_uiState.value.playerStats.highestCampaignWave, nextWave)
    )
    repository.saveUpgrades(updatedPerm)
    repository.saveStats(updatedStats)
    startWave(wave = nextWave, mode = GameMode.CAMPAIGN, savedUpgrades = updatedPerm)
  }

  fun retryCurrentWave() {
    startNewRun(_uiState.value.gameMode)
  }

  private fun startGameLoop() {
    viewModelScope.launch {
      var lastTimeMs = System.currentTimeMillis()
      while (isActive) {
        delay(16L)
        val nowMs = System.currentTimeMillis()
        val rawDt = ((nowMs - lastTimeMs) / 1000f).coerceIn(0.005f, 0.05f)
        lastTimeMs = nowMs
        val current = _uiState.value
        if (current.currentScreen == AppScreen.GAMEPLAY && current.status == GameStatus.PLAYING) {
          stepSimulation(rawDt * current.gameSpeedMultiplier)
        }
      }
    }
  }

  private fun stepSimulation(dt: Float) {
    val state = _uiState.value
    var playerX = state.playerX
    var squadCount = state.squadCount
    var bulletStreams = state.bulletStreams
    var bulletDamage = state.bulletDamage
    var fireRateMultiplier = state.fireRateMultiplier
    var overdriveTimer = (state.overdriveTimer - dt).coerceAtLeast(0f)
    var baseHp = state.baseHp
    val maxBaseHp = state.maxBaseHp
    var score = state.score
    var zombiesKilledInRun = state.zombiesKilledInRun
    var zombiesRemainingToSpawn = state.zombiesRemainingInWave
    var endlessElapsedSec = state.endlessElapsedSec
    var endlessThreatLevel = state.endlessThreatLevel
    var runGoldEarned = state.runGoldEarned
    var runCrystalsEarned = state.runCrystalsEarned
    var perm = state.permanentUpgrades
    var stats = state.playerStats

    val leftBarrels = state.leftBarrels.toMutableList()
    val rightBarrels = state.rightBarrels.toMutableList()
    val activeTurrets = state.activeTurrets.toMutableList()
    val fallingBuffs = state.fallingBuffs.toMutableList()
    val bridgeMines = state.bridgeMines.toMutableList()
    val sawblades = state.sawblades.toMutableList()
    val zombies = state.zombies.toMutableList()
    val projectiles = state.projectiles.toMutableList()
    val floatingTexts = state.floatingTexts.toMutableList()
    val particles = state.particles.toMutableList()

    // Helper for processing zombie deaths and drops
    val activeThreat = if (state.gameMode == GameMode.ENDLESS) endlessThreatLevel else state.waveNumber

    val processZombieKill = { deadZombie: Zombie ->
      zombiesKilledInRun++
      val goldGain = (deadZombie.type.goldReward * perm.bountyMultiplier).roundToInt().coerceAtLeast(1)
      runGoldEarned += goldGain
      score += goldGain * 10
      perm = perm.copy(gold = perm.gold + goldGain)

      val isBoss = deadZombie.type == ZombieType.BOSS
      val isElite = deadZombie.type in listOf(
        ZombieType.SHIELD_BRUTE,
        ZombieType.TOXIC_MUTANT,
        ZombieType.NECRO_SHAMAN,
        ZombieType.CYBER_JUGGERNAUT
      )

      var crystalDrop = 0
      if (Random.nextFloat() < deadZombie.type.crystalChance * perm.bountyMultiplier) {
        crystalDrop = if (isBoss) (4 + activeThreat / 2) else 1
        perm = perm.copy(crystals = perm.crystals + crystalDrop)
        runCrystalsEarned += crystalDrop
        floatingTexts += FloatingText(
          id = nextId(),
          x = deadZombie.x,
          y = deadZombie.y,
          text = "+$crystalDrop 💎",
          colorHex = 0xFF38BDF8,
          scale = 1.15f
        )
      }

      // Chance for killed Elite or Boss to drop a catchable Buff Capsule!
      if ((isBoss || (isElite && Random.nextFloat() < 0.28f)) && fallingBuffs.size < 4) {
        val dropType = DropBuffType.entries.random()
        fallingBuffs += FallingBuffDrop(
          id = nextId(),
          x = deadZombie.x.coerceIn(0.18f, 0.82f),
          y = deadZombie.y.coerceIn(0.10f, 0.55f),
          vy = 0.14f,
          type = dropType
        )
      }

      stats = stats.copy(
        totalZombiesKilled = stats.totalZombiesKilled + 1L,
        totalBossesKilled = stats.totalBossesKilled + (if (isBoss) 1 else 0),
        totalElitesKilled = stats.totalElitesKilled + (if (isElite) 1 else 0),
        lifetimeGoldEarned = stats.lifetimeGoldEarned + goldGain,
        lifetimeCrystalsEarned = stats.lifetimeCrystalsEarned + crystalDrop
      )
    }

    // Endless Mode progression: increase threat level every 24 seconds
    if (state.gameMode == GameMode.ENDLESS) {
      endlessElapsedSec += dt
      val calculatedThreat = 1 + (endlessElapsedSec / 24f).toInt() + (zombiesKilledInRun / 65)
      if (calculatedThreat > endlessThreatLevel) {
        endlessThreatLevel = calculatedThreat
        val crystalBonus = (1 + endlessThreatLevel / 3)
        perm = perm.copy(crystals = perm.crystals + crystalBonus)
        runCrystalsEarned += crystalBonus
        stats = stats.copy(
          bestEndlessThreatLevel = max(stats.bestEndlessThreatLevel, endlessThreatLevel),
          lifetimeCrystalsEarned = stats.lifetimeCrystalsEarned + crystalBonus
        )
        floatingTexts += FloatingText(
          id = nextId(),
          x = 0.50f,
          y = 0.20f,
          text = "🔥 УГРОЗА УР. $endlessThreatLevel! (+$crystalBonus 💎)",
          colorHex = 0xFFFACC15,
          scale = 1.25f,
          life = 1.5f
        )
      }
    }

    // Spawn periodic falling Airdrop Buffs that the player catches by moving at the bottom!
    buffDropSpawnAccumulator += dt
    if (buffDropSpawnAccumulator >= 8.5f && fallingBuffs.size < 3) {
      buffDropSpawnAccumulator = 0f
      val dropType = DropBuffType.entries.random()
      val dropX = Random.nextFloat() * 0.72f + 0.14f
      fallingBuffs += FallingBuffDrop(
        id = nextId(),
        x = dropX,
        y = 0.04f,
        vy = 0.125f,
        type = dropType
      )
    }

    // AutoPilot tactical assistant (also chases nearby falling buffs!)
    if (state.autoPilotEnabled) {
      val lowBuff = fallingBuffs.filter { it.y > 0.42f }.maxByOrNull { it.y }
      val frontZombieY = zombies.maxOfOrNull { it.y } ?: 0f
      val targetX = when {
        lowBuff != null -> lowBuff.x
        frontZombieY > 0.50f -> 0.50f
        activeTurrets.size < 2 && leftBarrels.isNotEmpty() && frontZombieY < 0.38f -> 0.095f
        rightBarrels.any { it.hp < 120 } && frontZombieY < 0.42f -> 0.905f
        else -> 0.50f
      }
      playerX += (targetX - playerX) * (dt * 4.5f).coerceAtMost(1f)
    }

    // Update Falling Buff Drops & Check Player Catch at y = 0.68f..0.85f!
    for (i in fallingBuffs.indices.reversed()) {
      val drop = fallingBuffs[i]
      val nextY = drop.y + drop.vy * dt
      val nextSway = drop.swayPhase + dt * 4f
      val caught = nextY in 0.67f..0.85f && abs(playerX - drop.x) < 0.105f

      if (caught) {
        fallingBuffs.removeAt(i)
        soundManager.playWaveVictory(perm.soundEnabled, perm.hapticsEnabled)
        when (drop.type) {
          DropBuffType.OVERDRIVE_FRENZY -> {
            overdriveTimer = 8.0f
            floatingTexts += FloatingText(
              id = nextId(),
              x = playerX,
              y = 0.68f,
              text = "⚡ Х2 БЕЗУМИЕ ОГНЯ (8 СЕК)!",
              colorHex = 0xFFFACC15,
              scale = 1.3f
            )
          }
          DropBuffType.AIRSTRIKE_BOMB -> {
            val bombDmg = (bulletDamage * 6.5f + activeThreat * 120f).roundToInt()
            for (zIdx in zombies.indices.reversed()) {
              val z = zombies[zIdx]
              val newHp = z.hp - bombDmg
              if (newHp <= 0) {
                zombies.removeAt(zIdx)
                processZombieKill(z)
              } else {
                zombies[zIdx] = z.copy(hp = newHp, hitFlash = 1f)
              }
            }
            repeat(22) {
              particles += VisualParticle(
                id = nextId(),
                x = Random.nextFloat() * 0.56f + 0.22f,
                y = Random.nextFloat() * 0.50f + 0.12f,
                vx = (Random.nextFloat() - 0.5f) * 0.22f,
                vy = (Random.nextFloat() - 0.5f) * 0.22f,
                radius = 9f,
                colorHex = 0xFFEF4444
              )
            }
            floatingTexts += FloatingText(
              id = nextId(),
              x = 0.50f,
              y = 0.38f,
              text = "💣 КОВРОВЫЙ АВИАУДАР! (-$bombDmg HP)",
              colorHex = 0xFFEF4444,
              scale = 1.35f
            )
          }
          DropBuffType.CRYO_NOVA -> {
            val frostDmg = (bulletDamage * 3.0f + activeThreat * 60f).roundToInt()
            for (zIdx in zombies.indices.reversed()) {
              val z = zombies[zIdx]
              val newHp = z.hp - frostDmg
              if (newHp <= 0) {
                zombies.removeAt(zIdx)
                processZombieKill(z)
              } else {
                zombies[zIdx] = z.copy(hp = newHp, slowTimer = 7.0f, hitFlash = 1f)
              }
            }
            floatingTexts += FloatingText(
              id = nextId(),
              x = 0.50f,
              y = 0.40f,
              text = "❄️ ЛЕДЯНАЯ НОВА! ОРДА ЗАМОРОЖЕНА!",
              colorHex = 0xFF38BDF8,
              scale = 1.3f
            )
          }
          DropBuffType.SHIELD_REPAIR -> {
            baseHp = min(maxBaseHp + 500, baseHp + 250)
            floatingTexts += FloatingText(
              id = nextId(),
              x = playerX,
              y = 0.70f,
              text = "🛡️ БАЗА +250 HP!",
              colorHex = 0xFF22C55E,
              scale = 1.3f
            )
          }
          DropBuffType.SQUAD_CLONE -> {
            squadCount += 1
            bulletStreams += 1
            floatingTexts += FloatingText(
              id = nextId(),
              x = playerX,
              y = 0.68f,
              text = "🐊 +1 ГЕРОЙ И +1 СТВОЛ!",
              colorHex = 0xFFA855F7,
              scale = 1.3f
            )
          }
          DropBuffType.TREASURE_CHEST -> {
            val goldBonus = (60 * perm.bountyMultiplier).roundToInt()
            val crystalBonus = 3
            runGoldEarned += goldBonus
            runCrystalsEarned += crystalBonus
            perm = perm.copy(gold = perm.gold + goldBonus, crystals = perm.crystals + crystalBonus)
            stats = stats.copy(
              lifetimeGoldEarned = stats.lifetimeGoldEarned + goldBonus,
              lifetimeCrystalsEarned = stats.lifetimeCrystalsEarned + crystalBonus
            )
            floatingTexts += FloatingText(
              id = nextId(),
              x = playerX,
              y = 0.68f,
              text = "💎 +$goldBonus 🪙 И +$crystalBonus 💎!",
              colorHex = 0xFFFACC15,
              scale = 1.3f
            )
          }
        }
      } else if (nextY > 0.89f) {
        fallingBuffs.removeAt(i)
      } else {
        fallingBuffs[i] = drop.copy(y = nextY, swayPhase = nextSway)
      }
    }

    // 1. Spawn player bullets from the Capybara Crocodile Squad (UNLIMITED streams & squad scaling!)
    val overdriveFactor = if (overdriveTimer > 0f) 1.85f else 1.0f
    val rawShotsPerSec = 5.8f * fireRateMultiplier * overdriveFactor
    val effectiveShotsPerSec = rawShotsPerSec.coerceAtMost(16.5f)
    // Any fire rate above 16.5 shots/sec seamlessly boosts bullet damage so unlimited fire-rate upgrades never waste DPS!
    val excessFireRateDmgBonus = if (rawShotsPerSec > 16.5f) (rawShotsPerSec / 16.5f) else 1.0f

    shootAccumulator += dt * effectiveShotsPerSec
    var muzzleFlash = (state.muzzleFlashIntensity - dt * 6f).coerceAtLeast(0f)

    while (shootAccumulator >= 1f) {
      shootAccumulator -= 1f
      muzzleFlash = 1f

      // Up to 12 physical streams fan out; if bulletStreams > 12, each physical stream carries the extra streams' full damage!
      val physicalStreams = bulletStreams.coerceIn(1, 12)
      val multiStreamCondensedMult = if (bulletStreams > 12) (bulletStreams.toFloat() / 12f) else 1.0f
      // Every single hero in squadCount increases damage with NO CAP!
      val squadBonusMult = 1.0f + (squadCount - 2).coerceAtLeast(0) * 0.22f
      val spreadWidth = (0.022f * (physicalStreams - 1)).coerceAtMost(0.22f)

      for (i in 0 until physicalStreams) {
        val offset = if (physicalStreams == 1) 0f else -spreadWidth / 2f + spreadWidth * (i.toFloat() / (physicalStreams - 1))
        val spawnX = (playerX + offset).coerceIn(0.04f, 0.96f)
        val isCrit = overdriveTimer > 0f || Random.nextFloat() < perm.critChance
        val finalDamage = (bulletDamage * squadBonusMult * multiStreamCondensedMult *
          excessFireRateDmgBonus * (if (isCrit) 2.2f else 1.0f)).roundToInt().coerceAtLeast(15)

        projectiles += Projectile(
          id = nextId(),
          x = spawnX,
          y = 0.76f,
          vx = offset * 0.08f,
          vy = -0.88f,
          damage = finalDamage,
          style = if (isCrit) ProjectileStyle.CRIT_BULLET else ProjectileStyle.STANDARD_BULLET,
          splashRadius = if (isCrit) 0.052f else 0.028f
        )
      }
    }

    // 2. Active Turrets on the Left Bridge Fence (x = 0.185f) fire into the wide Zombie Horde
    for (i in activeTurrets.indices) {
      val turret = activeTurrets[i]
      val newCooldown = turret.cooldown - dt
      val newRecoil = (turret.recoilAnim - dt * 4f).coerceAtLeast(0f)
      if (newCooldown <= 0f && zombies.isNotEmpty()) {
        val targetZombie = zombies.maxByOrNull { it.y }
        if (targetZombie != null) {
          val dx = targetZombie.x - 0.185f
          val dy = targetZombie.y - turret.y
          val dist = hypot(dx, dy).coerceAtLeast(0.01f)
          val speed = 0.72f
          val pStyle = when (turret.plantType) {
            PlantType.SPIDER_SHOOTER -> ProjectileStyle.PLANT_SEED
            PlantType.EGGPLANT_MORTAR -> ProjectileStyle.EGGPLANT_BOMB
            PlantType.TESLA_COIL -> ProjectileStyle.TESLA_BOLT
            PlantType.ANGRY_FLOWER -> ProjectileStyle.SOLAR_FLARE
            PlantType.FROST_CACTUS -> ProjectileStyle.FROST_SHARD
            else -> ProjectileStyle.PLANT_SEED
          }
          val levelScale = 1.0f + (turret.level - 1) * 0.38f
          val turretDmg = (turret.plantType.baseDamage * levelScale * perm.plantDamageMultiplier).roundToInt()

          projectiles += Projectile(
            id = nextId(),
            x = 0.19f,
            y = turret.y,
            vx = (dx / dist) * speed,
            vy = (dy / dist) * speed,
            damage = turretDmg,
            style = pStyle,
            passedGate = true,
            splashRadius = turret.plantType.splashRadius,
            appliesSlow = turret.plantType == PlantType.FROST_CACTUS
          )
          activeTurrets[i] = turret.copy(
            cooldown = turret.plantType.fireIntervalSec / (1f + (turret.level - 1) * 0.14f),
            recoilAnim = 1f
          )
        } else {
          activeTurrets[i] = turret.copy(cooldown = 0.1f, recoilAnim = newRecoil)
        }
      } else {
        activeTurrets[i] = turret.copy(cooldown = newCooldown, recoilAnim = newRecoil)
      }
    }

    // 2b. Update Spinning Sawblades rolling up the wide center bridge!
    for (sIdx in sawblades.indices.reversed()) {
      val blade = sawblades[sIdx]
      val nextY = blade.y + blade.vy * dt
      if (nextY < -0.06f) {
        sawblades.removeAt(sIdx)
      } else {
        for (zIdx in zombies.indices.reversed()) {
          val z = zombies[zIdx]
          if (hypot(z.x - blade.x, z.y - nextY) < 0.11f) {
            val newHp = z.hp - (blade.damage * dt * 8f).roundToInt().coerceAtLeast(18)
            if (newHp <= 0) {
              zombies.removeAt(zIdx)
              processZombieKill(z)
            } else {
              zombies[zIdx] = z.copy(hp = newHp, hitFlash = 1f)
            }
          }
        }
        sawblades[sIdx] = blade.copy(y = nextY, rotation = blade.rotation + dt * 720f)
      }
    }

    // 3. Move Projectiles, Check Multiplier Gates at y = 0.56f, and Collide
    val nextProjectiles = mutableListOf<Projectile>()
    val gateY = 0.56f

    for (proj in projectiles) {
      val oldY = proj.y
      val newX = proj.x + proj.vx * dt
      val newY = proj.y + proj.vy * dt

      if (newY < -0.05f || newY > 0.95f || newX < -0.05f || newX > 1.05f) {
        continue
      }

      // Check Left Gate (x < 0.19f) or Right Gate (x > 0.81f) at y = 0.56f
      if (!proj.passedGate && oldY >= gateY && newY < gateY) {
        if (newX < 0.19f) {
          val mult = state.leftGateMultiplier
          for (m in 0 until mult) {
            val spread = (m - (mult - 1) / 2f) * 0.016f
            nextProjectiles += proj.copy(
              id = nextId(),
              x = (newX + spread).coerceIn(0.03f, 0.17f),
              y = newY,
              vx = spread * 0.12f,
              style = ProjectileStyle.LEFT_GATE_BLUE,
              passedGate = true
            )
          }
          continue
        } else if (newX > 0.81f) {
          val mult = state.rightGateMultiplier
          for (m in 0 until mult) {
            val spread = (m - (mult - 1) / 2f) * 0.016f
            nextProjectiles += proj.copy(
              id = nextId(),
              x = (newX + spread).coerceIn(0.83f, 0.97f),
              y = newY,
              vx = spread * 0.12f,
              style = ProjectileStyle.RIGHT_GATE_FIRE,
              passedGate = true
            )
          }
          continue
        }
      }

      var consumed = false

      // Left Lane Barrels collision (x < 0.195f)
      if (newX < 0.195f && leftBarrels.isNotEmpty()) {
        val targetIndex = leftBarrels.indexOfFirst { barrel ->
          abs(newY - barrel.y) < 0.055f
        }
        if (targetIndex != -1) {
          consumed = true
          val barrel = leftBarrels[targetIndex]
          val newHp = barrel.hp - perm.barrelBreakerPower
          soundManager.playHitTick(perm.soundEnabled)
          if (newHp <= 0) {
            leftBarrels.removeAt(targetIndex)
            leftBarrelsBrokenInRun++
            stats = stats.copy(totalLeftBarrelsBroken = stats.totalLeftBarrelsBroken + 1)
            soundManager.playPlantUnlocked(perm.soundEnabled, perm.hapticsEnabled)

            when (barrel.plantType) {
              PlantType.SAWBLADE_ROLLER -> {
                // Launch 3 giant spinning sawblades up the wide center lane!
                val bladeDmg = (barrel.plantType.baseDamage * perm.plantDamageMultiplier * (1f + activeThreat * 0.25f)).roundToInt()
                for (bx in listOf(0.32f, 0.50f, 0.68f)) {
                  sawblades += SawbladeWave(
                    id = nextId(),
                    x = bx,
                    y = 0.69f,
                    damage = bladeDmg
                  )
                }
                floatingTexts += FloatingText(
                  id = nextId(),
                  x = 0.50f,
                  y = 0.55f,
                  text = "⚙️ ЦИРКУЛЯРНЫЕ КАТКИ ЗАПУЩЕНЫ!",
                  colorHex = 0xFF38BDF8,
                  scale = 1.25f
                )
              }
              PlantType.MINEFIELD_TRAP -> {
                // Lay 5 explosive mines across the wide center bridge!
                val mineDmg = (barrel.plantType.baseDamage * perm.plantDamageMultiplier * (1f + activeThreat * 0.30f)).roundToInt()
                for (m in 0 until 5) {
                  val mx = 0.26f + m * 0.12f
                  val my = (0.58f + (m % 2) * 0.04f).coerceIn(0.45f, 0.66f)
                  bridgeMines += BridgeMine(
                    id = nextId(),
                    x = mx,
                    y = my,
                    damage = mineDmg
                  )
                }
                floatingTexts += FloatingText(
                  id = nextId(),
                  x = 0.50f,
                  y = 0.56f,
                  text = "🧨 МИННОЕ ПОЛЕ УСТАНОВЛЕНО!",
                  colorHex = 0xFFFACC15,
                  scale = 1.25f
                )
              }
              PlantType.NAPALM_BARRAGE -> {
                // Scorch the entire center bridge with Napalm!
                val napalmDmg = (barrel.plantType.baseDamage * perm.plantDamageMultiplier * (1f + activeThreat * 0.30f)).roundToInt()
                for (zIdx in zombies.indices.reversed()) {
                  val z = zombies[zIdx]
                  val updatedHp = z.hp - napalmDmg
                  if (updatedHp <= 0) {
                    zombies.removeAt(zIdx)
                    processZombieKill(z)
                  } else {
                    zombies[zIdx] = z.copy(hp = updatedHp, hitFlash = 1f)
                  }
                }
                repeat(18) {
                  particles += VisualParticle(
                    id = nextId(),
                    x = Random.nextFloat() * 0.54f + 0.23f,
                    y = Random.nextFloat() * 0.48f + 0.15f,
                    vx = (Random.nextFloat() - 0.5f) * 0.18f,
                    vy = (Random.nextFloat() - 0.5f) * 0.18f,
                    radius = 8f,
                    colorHex = 0xFFF97316
                  )
                }
                floatingTexts += FloatingText(
                  id = nextId(),
                  x = 0.50f,
                  y = 0.42f,
                  text = "🔥 ОГНЕННЫЙ ЗАЛП НАПАЛМА!",
                  colorHex = 0xFFF97316,
                  scale = 1.3f
                )
              }
              else -> {
                // Mount or upgrade Turret on the Left Fence!
                val existingIdx = activeTurrets.indexOfFirst { it.plantType == barrel.plantType }
                if (existingIdx != -1) {
                  val existing = activeTurrets[existingIdx]
                  activeTurrets[existingIdx] = existing.copy(level = existing.level + 1, recoilAnim = 1f)
                  floatingTexts += FloatingText(
                    id = nextId(),
                    x = 0.18f,
                    y = barrel.y,
                    text = "${barrel.plantType.titleRu} УР. ${existing.level + 1}!",
                    colorHex = 0xFF4ADE80,
                    scale = 1.15f
                  )
                } else {
                  val slotIdx = activeTurrets.size
                  val slotY = (0.48f - slotIdx * 0.088f).coerceIn(0.10f, 0.50f)
                  activeTurrets += ActiveTurret(
                    id = nextId(),
                    slotIndex = slotIdx,
                    y = slotY,
                    plantType = barrel.plantType,
                    level = 1,
                    recoilAnim = 1f
                  )
                  floatingTexts += FloatingText(
                    id = nextId(),
                    x = 0.18f,
                    y = slotY,
                    text = "+ ${barrel.plantType.titleRu}!",
                    colorHex = 0xFF22C55E,
                    scale = 1.2f
                  )
                }
              }
            }

            for (k in leftBarrels.indices) {
              leftBarrels[k] = leftBarrels[k].copy(
                y = (0.44f - k * 0.15f).coerceIn(0.07f, 0.46f)
              )
            }
            val nextPlant = PlantType.entries[(activeThreat + leftBarrelsBrokenInRun) % PlantType.entries.size]
            val scaledHits = (nextPlant.baseHitsRequired * (1.32f).pow(leftBarrelsBrokenInRun.coerceAtMost(14))).roundToInt()
            leftBarrels += LeftBarrel(
              id = nextId(),
              y = 0.08f,
              hp = scaledHits,
              maxHp = scaledHits,
              plantType = nextPlant
            )
          } else {
            leftBarrels[targetIndex] = barrel.copy(hp = newHp, hitFlash = 1f)
          }
        }
      }

      // Right Lane Upgrade Barrels collision (x > 0.805f) — UNLIMITED UPGRADES!
      if (!consumed && newX > 0.805f && rightBarrels.isNotEmpty()) {
        val targetIndex = rightBarrels.indexOfFirst { barrel ->
          abs(newY - barrel.y) < 0.052f
        }
        if (targetIndex != -1) {
          consumed = true
          val barrel = rightBarrels[targetIndex]
          val newHp = barrel.hp - perm.barrelBreakerPower
          soundManager.playHitTick(perm.soundEnabled)
          if (newHp <= 0) {
            rightBarrels.removeAt(targetIndex)
            rightBarrelsBrokenInRun++
            stats = stats.copy(totalRightBarrelsBroken = stats.totalRightBarrelsBroken + 1)
            soundManager.playBarrelBreak(perm.soundEnabled, perm.hapticsEnabled)

            when (barrel.upgradeType) {
              UpgradeType.FIRE_RATE_BOOST -> {
                fireRateMultiplier += 0.18f
                floatingTexts += FloatingText(
                  id = nextId(),
                  x = 0.84f,
                  y = barrel.y,
                  text = "ТЕМП ОГНЯ +18% (x${"%.1f".format(fireRateMultiplier)})!",
                  colorHex = 0xFFFACC15,
                  scale = 1.2f
                )
              }
              UpgradeType.ATTACK_BOOST -> {
                val dmgGain = max(12, (bulletDamage * 0.25f).roundToInt())
                bulletDamage += dmgGain
                floatingTexts += FloatingText(
                  id = nextId(),
                  x = 0.84f,
                  y = barrel.y,
                  text = "УРОН +$dmgGain ($bulletDamage)!",
                  colorHex = 0xFFF87171,
                  scale = 1.2f
                )
              }
              UpgradeType.BULLETS_PLUS_1 -> {
                bulletStreams += 1
                floatingTexts += FloatingText(
                  id = nextId(),
                  x = 0.84f,
                  y = barrel.y,
                  text = "СТВОЛЫ +1 (ВСЕГО: $bulletStreams)!",
                  colorHex = 0xFF38BDF8,
                  scale = 1.25f
                )
              }
              UpgradeType.HERO_PLUS_1 -> {
                squadCount += 1
                floatingTexts += FloatingText(
                  id = nextId(),
                  x = 0.84f,
                  y = barrel.y,
                  text = "ОТРЯД +1 (КАПИБАР: $squadCount)!",
                  colorHex = 0xFF4ADE80,
                  scale = 1.25f
                )
              }
            }

            for (k in rightBarrels.indices) {
              rightBarrels[k] = rightBarrels[k].copy(
                y = (0.45f - k * 0.12f).coerceIn(0.08f, 0.46f)
              )
            }
            val nextUpgrade = UpgradeType.entries[rightBarrelsBrokenInRun % UpgradeType.entries.size]
            val nextHp = (nextUpgrade.baseHitsRequired * (1.30f).pow(rightBarrelsBrokenInRun.coerceAtMost(18))).roundToInt()
            rightBarrels += RightBarrel(
              id = nextId(),
              y = 0.08f,
              hp = nextHp,
              maxHp = nextHp,
              upgradeType = nextUpgrade,
              bonusAmount = when (nextUpgrade) {
                UpgradeType.ATTACK_BOOST -> 25
                UpgradeType.FIRE_RATE_BOOST -> 18
                else -> 1
              }
            )
          } else {
            rightBarrels[targetIndex] = barrel.copy(hp = newHp, hitFlash = 1f)
          }
        }
      }

      // Center Lane Zombie Horde collision (wide center: x in 0.18f..0.82f)
      if (!consumed && newX in 0.18f..0.82f && zombies.isNotEmpty()) {
        val hitIdx = zombies.indexOfFirst { z ->
          val hitRadius = if (z.type == ZombieType.BOSS) 0.068f else 0.042f
          abs(newX - z.x) < hitRadius && abs(newY - z.y) < hitRadius
        }
        if (hitIdx != -1) {
          consumed = true
          val primaryZombie = zombies[hitIdx]
          val hitX = primaryZombie.x
          val hitY = primaryZombie.y

          if (proj.splashRadius > 0f) {
            for (zIdx in zombies.indices.reversed()) {
              val z = zombies[zIdx]
              if (hypot(z.x - hitX, z.y - hitY) <= proj.splashRadius) {
                val isPrimary = z.id == primaryZombie.id
                val splashFactor = if (isPrimary) 1.0f else 0.60f
                val effectiveDmg = (proj.damage * splashFactor * (1f - z.type.armorReduction)).roundToInt().coerceAtLeast(4)
                val updatedHp = z.hp - effectiveDmg
                if (updatedHp <= 0) {
                  zombies.removeAt(zIdx)
                  processZombieKill(z)
                } else {
                  zombies[zIdx] = z.copy(
                    hp = updatedHp,
                    hitFlash = 1f,
                    slowTimer = if (proj.appliesSlow) 2.6f else z.slowTimer
                  )
                }
              }
            }
          } else {
            val effectiveDmg = (proj.damage * (1f - primaryZombie.type.armorReduction)).roundToInt().coerceAtLeast(4)
            val updatedHp = primaryZombie.hp - effectiveDmg
            if (updatedHp <= 0) {
              zombies.removeAt(hitIdx)
              processZombieKill(primaryZombie)
            } else {
              zombies[hitIdx] = primaryZombie.copy(
                hp = updatedHp,
                hitFlash = 1f,
                slowTimer = if (proj.appliesSlow) 2.6f else primaryZombie.slowTimer
              )
            }
          }
        }
      }

      if (!consumed) {
        nextProjectiles += proj.copy(x = newX, y = newY)
      }
    }

    // 4. Decay barrel hit flashes
    for (i in leftBarrels.indices) {
      if (leftBarrels[i].hitFlash > 0f) {
        leftBarrels[i] = leftBarrels[i].copy(hitFlash = (leftBarrels[i].hitFlash - dt * 6f).coerceAtLeast(0f))
      }
    }
    for (i in rightBarrels.indices) {
      if (rightBarrels[i].hitFlash > 0f) {
        rightBarrels[i] = rightBarrels[i].copy(hitFlash = (rightBarrels[i].hitFlash - dt * 6f).coerceAtLeast(0f))
      }
    }

    // 5. March Zombies Down the Wide Center Bridge Lane + Check Landmines & Hazard Line (y = 0.71f)
    var dangerFlash = (state.dangerFlashIntensity - dt * 2.5f).coerceAtLeast(0f)
    val baseMarchSpeed = (0.021f + (activeThreat - 1) * 0.0022f).coerceAtMost(0.062f)

    for (i in zombies.indices.reversed()) {
      val z = zombies[i]
      val slowFactor = if (z.slowTimer > 0f) 0.50f else 1.0f
      val dy = baseMarchSpeed * z.type.speedMultiplier * slowFactor * dt
      val nextY = z.y + dy

      // Check if zombie stepped on a BridgeMine!
      val triggeredMineIdx = bridgeMines.indexOfFirst { m ->
        hypot(m.x - z.x, m.y - nextY) < 0.06f
      }
      if (triggeredMineIdx != -1) {
        val mine = bridgeMines.removeAt(triggeredMineIdx)
        soundManager.playBarrelBreak(perm.soundEnabled, perm.hapticsEnabled)
        for (zIdx in zombies.indices.reversed()) {
          val targetZ = zombies[zIdx]
          if (hypot(targetZ.x - mine.x, targetZ.y - mine.y) <= mine.splashRadius) {
            val newHp = targetZ.hp - mine.damage
            if (newHp <= 0) {
              zombies.removeAt(zIdx)
              processZombieKill(targetZ)
            } else {
              zombies[zIdx] = targetZ.copy(hp = newHp, hitFlash = 1f)
            }
          }
        }
        repeat(10) {
          val angle = Random.nextFloat() * 6.28f
          particles += VisualParticle(
            id = nextId(),
            x = mine.x,
            y = mine.y,
            vx = cos(angle) * 0.18f,
            vy = sin(angle) * 0.18f,
            radius = 6f,
            colorHex = 0xFFEF4444
          )
        }
        continue
      }

      var nextHealTimer = z.healPulseTimer - dt
      if (z.type == ZombieType.NECRO_SHAMAN && nextHealTimer <= 0f) {
        nextHealTimer = 3.0f
        for (k in zombies.indices) {
          val ally = zombies[k]
          if (hypot(ally.x - z.x, ally.y - z.y) < 0.14f && ally.hp < ally.maxHp) {
            val healAmt = (ally.maxHp * 0.10f).roundToInt().coerceAtLeast(20)
            zombies[k] = ally.copy(hp = min(ally.maxHp, ally.hp + healAmt))
          }
        }
      }

      if (nextY >= 0.71f) {
        val dmg = when (z.type) {
          ZombieType.BOSS -> 300
          ZombieType.CYBER_JUGGERNAUT, ZombieType.SHIELD_BRUTE -> 70
          else -> 35
        }
        baseHp = (baseHp - dmg).coerceAtLeast(0)
        dangerFlash = 1f
        soundManager.playDamageAlert(perm.soundEnabled, perm.hapticsEnabled)
        floatingTexts += FloatingText(
          id = nextId(),
          x = z.x,
          y = 0.70f,
          text = "-$dmg HP!",
          colorHex = 0xFFEF4444,
          scale = 1.2f
        )
        zombies.removeAt(i)
      } else {
        zombies[i] = z.copy(
          y = nextY,
          walkPhase = z.walkPhase + dt * 9f * slowFactor,
          hitFlash = (z.hitFlash - dt * 6f).coerceAtLeast(0f),
          slowTimer = (z.slowTimer - dt).coerceAtLeast(0f),
          healPulseTimer = nextHealTimer
        )
      }
    }

    // 6. Spawn New Zombie Rows from the Top of the Bridge
    if (zombiesRemainingToSpawn > 0) {
      zombieRowSpawnAccumulator += dt
      val spawnInterval = (1.42f - (activeThreat - 1) * 0.045f).coerceIn(0.68f, 1.42f)
      val highestRowY = zombies.minOfOrNull { it.y } ?: 0.50f
      if (zombieRowSpawnAccumulator >= spawnInterval && highestRowY > 0.03f) {
        zombieRowSpawnAccumulator = 0f
        val newRow = createZombieRow(rowY = -0.03f, threatLevel = activeThreat, rowNumber = zombieRowCounter++)
        zombies += newRow
        if (state.gameMode == GameMode.CAMPAIGN) {
          zombiesRemainingToSpawn = (zombiesRemainingToSpawn - newRow.size).coerceAtLeast(0)
        }

        val shouldSpawnEndlessBoss = state.gameMode == GameMode.ENDLESS && zombieRowCounter % 9 == 0
        val shouldSpawnCampaignBoss = state.gameMode == GameMode.CAMPAIGN && zombiesRemainingToSpawn <= 14 && !bossSpawnedForWave

        if (shouldSpawnEndlessBoss || shouldSpawnCampaignBoss) {
          bossSpawnedForWave = true
          val bossHp = (1100f * (1.25f).pow((activeThreat - 1).coerceAtMost(25)) + activeThreat * 450f).roundToInt()
          zombies += Zombie(
            id = nextId(),
            x = 0.50f,
            y = -0.09f,
            rowId = zombieRowCounter++,
            colIndex = 3,
            hp = bossHp,
            maxHp = bossHp,
            type = ZombieType.BOSS
          )
          floatingTexts += FloatingText(
            id = nextId(),
            x = 0.50f,
            y = 0.24f,
            text = "⚠ ТИТАН-БОСС (УР. $activeThreat) ВЫШЕЛ НА МОСТ! ⚠",
            colorHex = 0xFFEF4444,
            scale = 1.25f,
            life = 1.6f
          )
        }
      }
    }

    // 7. Update Floating Texts & Particles
    val updatedTexts = floatingTexts.mapNotNull { ft ->
      val nextLife = ft.life - dt
      if (nextLife <= 0f) null
      else ft.copy(
        y = ft.y - dt * 0.055f,
        life = nextLife,
        alpha = (nextLife / 0.9f).coerceIn(0f, 1f)
      )
    }

    val updatedParticles = particles.mapNotNull { p ->
      val nextLife = p.life - dt
      if (nextLife <= 0f) null
      else p.copy(
        x = p.x + p.vx * dt,
        y = p.y + p.vy * dt,
        life = nextLife,
        alpha = (nextLife / 0.45f).coerceIn(0f, 1f)
      )
    }

    // 8. Check Victory or Game Over
    var nextStatus = state.status
    if (baseHp <= 0) {
      nextStatus = GameStatus.GAME_OVER
      val survivalBonusCrystals = max(3, (activeThreat * 2 + zombiesKilledInRun / 25))
      runCrystalsEarned += survivalBonusCrystals
      perm = perm.copy(
        crystals = perm.crystals + survivalBonusCrystals,
        highScore = max(perm.highScore, score)
      )
      stats = stats.copy(
        bestScore = max(stats.bestScore, score),
        bestEndlessThreatLevel = max(stats.bestEndlessThreatLevel, endlessThreatLevel),
        bestEndlessTimeSec = max(stats.bestEndlessTimeSec, endlessElapsedSec.toInt()),
        lifetimeCrystalsEarned = stats.lifetimeCrystalsEarned + survivalBonusCrystals
      )
      repository.saveUpgrades(perm)
      repository.saveStats(stats)
    } else if (state.gameMode == GameMode.CAMPAIGN && zombiesRemainingToSpawn <= 0 && zombies.isEmpty()) {
      nextStatus = GameStatus.WAVE_VICTORY
      val bonusGold = 60 + state.waveNumber * 30
      val bonusCrystals = 5 + state.waveNumber * 2
      runGoldEarned += bonusGold
      runCrystalsEarned += bonusCrystals
      perm = perm.copy(
        gold = perm.gold + bonusGold,
        crystals = perm.crystals + bonusCrystals,
        highScore = max(perm.highScore, score + bonusGold * 10),
        unlockedWave = max(perm.unlockedWave, state.waveNumber + 1)
      )
      stats = stats.copy(
        bestScore = max(stats.bestScore, score + bonusGold * 10),
        highestCampaignWave = max(stats.highestCampaignWave, state.waveNumber + 1),
        lifetimeGoldEarned = stats.lifetimeGoldEarned + bonusGold,
        lifetimeCrystalsEarned = stats.lifetimeCrystalsEarned + bonusCrystals
      )
      repository.saveUpgrades(perm)
      repository.saveStats(stats)
      soundManager.playWaveVictory(perm.soundEnabled, perm.hapticsEnabled)
    }

    _uiState.update {
      it.copy(
        status = nextStatus,
        playerX = playerX,
        squadCount = squadCount,
        bulletStreams = bulletStreams,
        bulletDamage = bulletDamage,
        fireRateMultiplier = fireRateMultiplier,
        overdriveTimer = overdriveTimer,
        baseHp = baseHp,
        score = score,
        endlessThreatLevel = endlessThreatLevel,
        endlessElapsedSec = endlessElapsedSec,
        runGoldEarned = runGoldEarned,
        runCrystalsEarned = runCrystalsEarned,
        zombiesRemainingInWave = zombiesRemainingToSpawn,
        zombiesKilledInRun = zombiesKilledInRun,
        leftBarrels = leftBarrels,
        activeTurrets = activeTurrets,
        rightBarrels = rightBarrels,
        fallingBuffs = fallingBuffs,
        bridgeMines = bridgeMines,
        sawblades = sawblades,
        zombies = zombies,
        projectiles = nextProjectiles,
        floatingTexts = updatedTexts,
        particles = updatedParticles,
        muzzleFlashIntensity = muzzleFlash,
        dangerFlashIntensity = dangerFlash,
        permanentUpgrades = perm,
        playerStats = stats
      )
    }
  }

  class Factory(
    private val repository: GamePreferencesRepository,
    private val soundManager: SoundAndHapticsManager
  ) : ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
      return BridgeGameViewModel(repository, soundManager) as T
    }
  }
}
