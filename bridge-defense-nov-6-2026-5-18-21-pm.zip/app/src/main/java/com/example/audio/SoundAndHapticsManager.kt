package com.example.audio

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

class SoundAndHapticsManager(context: Context) {
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
  private val vibrator: Vibrator? =
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      val vm = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
      vm?.defaultVibrator
    } else {
      @Suppress("DEPRECATION")
      context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

  private var lastTickMs = 0L

  fun playHitTick(soundEnabled: Boolean) {
    if (!soundEnabled) return
    val now = System.currentTimeMillis()
    if (now - lastTickMs < 65L) return
    lastTickMs = now
    scope.launch {
      playTone(startFreq = 520.0, endFreq = 780.0, durationMs = 28, volume = 0.14f)
    }
  }

  fun playBarrelBreak(soundEnabled: Boolean, hapticsEnabled: Boolean) {
    if (hapticsEnabled) vibrate(25L)
    if (!soundEnabled) return
    scope.launch {
      playTone(startFreq = 440.0, endFreq = 880.0, durationMs = 95, volume = 0.28f)
      playTone(startFreq = 660.0, endFreq = 1320.0, durationMs = 120, volume = 0.30f)
    }
  }

  fun playPlantUnlocked(soundEnabled: Boolean, hapticsEnabled: Boolean) {
    if (hapticsEnabled) vibrate(40L)
    if (!soundEnabled) return
    scope.launch {
      playTone(startFreq = 523.25, endFreq = 659.25, durationMs = 85, volume = 0.30f)
      playTone(startFreq = 659.25, endFreq = 1046.50, durationMs = 150, volume = 0.34f)
    }
  }

  fun playWaveVictory(soundEnabled: Boolean, hapticsEnabled: Boolean) {
    if (hapticsEnabled) vibrate(60L)
    if (!soundEnabled) return
    scope.launch {
      playTone(startFreq = 523.25, endFreq = 523.25, durationMs = 90, volume = 0.32f)
      playTone(startFreq = 659.25, endFreq = 659.25, durationMs = 90, volume = 0.32f)
      playTone(startFreq = 783.99, endFreq = 1046.50, durationMs = 200, volume = 0.36f)
    }
  }

  fun playDamageAlert(soundEnabled: Boolean, hapticsEnabled: Boolean) {
    if (hapticsEnabled) vibrate(45L)
    if (!soundEnabled) return
    scope.launch {
      playTone(startFreq = 240.0, endFreq = 140.0, durationMs = 110, volume = 0.30f)
    }
  }

  private fun vibrate(ms: Long) {
    try {
      val v = vibrator ?: return
      if (!v.hasVibrator()) return
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
        v.vibrate(VibrationEffect.createOneShot(ms, VibrationEffect.DEFAULT_AMPLITUDE))
      } else {
        @Suppress("DEPRECATION")
        v.vibrate(ms)
      }
    } catch (_: Throwable) {
      // Ignore on devices without vibrator support
    }
  }

  private fun playTone(startFreq: Double, endFreq: Double, durationMs: Int, volume: Float) {
    try {
      val sampleRate = 22050
      val numSamples = (durationMs * sampleRate) / 1000
      if (numSamples <= 0) return
      val buffer = ShortArray(numSamples)
      var phase = 0.0
      for (i in 0 until numSamples) {
        val progress = i.toDouble() / numSamples
        val freq = startFreq + (endFreq - startFreq) * progress
        val env = (1.0 - progress).coerceIn(0.0, 1.0)
        val sample = sin(phase) * volume * env
        buffer[i] = (sample * Short.MAX_VALUE).toInt().toShort()
        phase += 2.0 * PI * freq / sampleRate
      }

      val track = AudioTrack.Builder()
        .setAudioAttributes(
          AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()
        )
        .setAudioFormat(
          AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(sampleRate)
            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
            .build()
        )
        .setBufferSizeInBytes(buffer.size * 2)
        .setTransferMode(AudioTrack.MODE_STATIC)
        .build()

      track.write(buffer, 0, buffer.size)
      track.play()
      Thread.sleep(durationMs.toLong() + 15L)
      track.release()
    } catch (_: Throwable) {
      // Safe fallback in headless/unit test environments
    }
  }
}
